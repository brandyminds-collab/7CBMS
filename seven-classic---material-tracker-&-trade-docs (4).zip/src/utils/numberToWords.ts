/**
 * Utility to convert numbers into official banking uppercase words format
 * Example: 19805.39 -> "SAY US DOLLARS NINETEEN THOUSAND EIGHT HUNDRED FIVE AND CENTS THIRTY NINE ONLY"
 */

const ONES = [
  '',
  'ONE',
  'TWO',
  'THREE',
  'FOUR',
  'FIVE',
  'SIX',
  'SEVEN',
  'EIGHT',
  'NINE',
  'TEN',
  'ELEVEN',
  'TWELVE',
  'THIRTEEN',
  'FOURTEEN',
  'FIFTEEN',
  'SIXTEEN',
  'SEVENTEEN',
  'EIGHTEEN',
  'NINETEEN',
];

const TENS = [
  '',
  '',
  'TWENTY',
  'THIRTY',
  'FORTY',
  'FIFTY',
  'SIXTY',
  'SEVENTY',
  'EIGHTY',
  'NINETY',
];

function convertLessThanThousand(num: number): string {
  if (num === 0) return '';
  if (num < 20) return ONES[num];
  const ten = Math.floor(num / 10);
  const remainder = num % 10;
  if (num < 100) {
    return `${TENS[ten]}${remainder ? ` ${ONES[remainder]}` : ''}`;
  }
  const hundred = Math.floor(num / 100);
  const rest = num % 100;
  return `${ONES[hundred]} HUNDRED${rest ? ` ${convertLessThanThousand(rest)}` : ''}`;
}

export function numberToWordsUSD(amount: number): string {
  if (!amount || isNaN(amount) || amount <= 0) {
    return 'SAY US DOLLARS ZERO ONLY';
  }

  const fixed = amount.toFixed(2);
  const [dollarsStr, centsStr] = fixed.split('.');
  let dollars = parseInt(dollarsStr, 10);
  const cents = parseInt(centsStr, 10);

  const scales = [
    { value: 1000000000, name: 'BILLION' },
    { value: 1000000, name: 'MILLION' },
    { value: 1000, name: 'THOUSAND' },
  ];

  const parts: string[] = [];

  for (const scale of scales) {
    if (dollars >= scale.value) {
      const count = Math.floor(dollars / scale.value);
      parts.push(`${convertLessThanThousand(count)} ${scale.name}`);
      dollars %= scale.value;
    }
  }

  if (dollars > 0) {
    parts.push(convertLessThanThousand(dollars));
  }

  const dollarWords = parts.join(' ').trim() || 'ZERO';

  let centsWords = '';
  if (cents > 0) {
    centsWords = ` AND CENTS ${convertLessThanThousand(cents)}`;
  }

  return `SAY US DOLLARS ${dollarWords}${centsWords} ONLY`.replace(/\s+/g, ' ');
}
