import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { DocTemplateType, TradeDocumentData } from '../types';

// Helper for bottom 3-line footer (Head Office, Factory, Cell)
function drawStandardFooter(
  doc: jsPDF,
  data: TradeDocumentData,
  pageWidth: number,
  pageHeight: number,
  margin: number
) {
  const bottomY = pageHeight - 16;
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.4);
  doc.line(margin, bottomY - 3, pageWidth - margin, bottomY - 3);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.8);
  doc.setTextColor(0, 0, 0);
  doc.text(`HEAD OFFICE : ${data.exporter?.headOffice || ''}`, margin + 1, bottomY);
  doc.text(`FACTORY : ${data.exporter?.factory || ''}`, margin + 1, bottomY + 3.2);
  doc.text(
    `CELL : ${data.exporter?.cell || ''}. Email : ${data.exporter?.email || ''}`,
    margin + 1,
    bottomY + 6.4
  );
}

// Helper for dynamic Party and Bank information
function getPartyAndBankInfo(data: TradeDocumentData) {
  const buyerName = data.buyer?.name?.trim() || '';
  const notifyName = data.notifyParty?.name?.trim() || '';
  const applicantName = buyerName || notifyName || '';
  const notifyPartyName = notifyName || buyerName || '';

  const applicantAddress =
    data.buyer?.address?.trim() ||
    data.buyer?.plotNo?.trim() ||
    data.notifyParty?.address?.trim() ||
    '';

  const postPart = data.buyer?.post ? `POST : ${data.buyer.post}` : '';
  const psPart = data.buyer?.ps ? `PS: ${data.buyer.ps}` : '';
  const districtPart = data.buyer?.district || '';
  const countryPart = data.buyer?.country || 'BANGLADESH';

  const bankName = data.applicantBank?.bankName?.trim() || '';
  const bankBranch = data.applicantBank?.branch?.trim() || '';
  const bankAddress = data.applicantBank?.address?.trim() || '';

  return {
    applicantName,
    notifyPartyName,
    applicantAddress,
    postPart,
    psPart,
    districtPart,
    countryPart,
    bankName,
    bankBranch,
    bankAddress,
  };
}

// ==========================================
// 1. PAGE 1: COMMERCIAL INVOICE
// ==========================================
export function renderCommercialInvoice(
  doc: jsPDF,
  data: TradeDocumentData,
  margin = 12,
  pageWidth = 210,
  pageHeight = 297
) {
  const contentWidth = pageWidth - margin * 2;
  const items = data.items || [];

  // Outer border
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.6);
  doc.rect(margin, margin, contentWidth, pageHeight - margin * 2);

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(0, 0, 0);
  doc.text(
    data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.',
    pageWidth / 2,
    margin + 7,
    { align: 'center' }
  );

  doc.setFontSize(12);
  doc.text('COMMERCIAL INVOICE', pageWidth / 2, margin + 13, { align: 'center' });

  // Header line
  doc.setLineWidth(0.4);
  doc.line(margin, margin + 15, pageWidth - margin, margin + 15);

  let curY = margin + 15;
  const midX = margin + contentWidth * 0.52;

  // Row 1: Shipper / Invoice No
  const r1H = 16;
  doc.line(margin, curY + r1H, pageWidth - margin, curY + r1H);
  doc.line(midX, curY, midX, curY + r1H);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('SHIPPER/ EXPORTER :-', margin + 2, curY + 4);
  doc.text(data.exporter?.name || '', margin + 2, curY + 7.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text('1,NO SADHU MADBOR ROAD,MAMUDPUR,', margin + 2, curY + 11);
  doc.text('BHUIGHAR,FATULLAH,NARAYONGONJ.', margin + 2, curY + 14.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('Invoice No.', midX + 2, curY + 4);
  doc.setFont('helvetica', 'normal');
  doc.text(data.invoiceNo || '', midX + 22, curY + 4);
  doc.text(`Date.${data.invoiceDate || ''}`, midX + 50, curY + 4);

  doc.line(midX, curY + 7.5, pageWidth - margin, curY + 7.5);
  doc.setFont('helvetica', 'bold');
  doc.text('L/C NO.', midX + 2, curY + 12);
  doc.setFont('helvetica', 'normal');
  doc.text(data.lcNo || '', midX + 16, curY + 12);
  doc.text(`Date.${data.lcDate || ''}`, midX + 50, curY + 12);

  curY += r1H;

  // Row 2: Notify Party & Bank / Registration
  const r2H = 34;
  doc.line(margin, curY + r2H, pageWidth - margin, curY + r2H);
  doc.line(midX, curY, midX, curY + r2H);

  const {
    applicantName,
    notifyPartyName,
    applicantAddress,
    postPart,
    psPart,
    districtPart,
    countryPart,
    bankName,
    bankBranch,
    bankAddress,
  } = getPartyAndBankInfo(data);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('NOTIFY PARTY/APPLICANT.:', margin + 2, curY + 4);

  if (
    notifyPartyName &&
    applicantName &&
    notifyPartyName.toLowerCase() !== applicantName.toLowerCase()
  ) {
    doc.text(`NOTIFY: ${notifyPartyName.slice(0, 48)}`, margin + 2, curY + 7.5);
    doc.text(`APPLICANT: ${applicantName.slice(0, 46)}`, margin + 2, curY + 11);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text(applicantAddress.slice(0, 52), margin + 2, curY + 14.5);
  } else {
    doc.text(applicantName, margin + 2, curY + 7.5);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text(applicantAddress.slice(0, 52), margin + 2, curY + 11);
    if (postPart || psPart) {
      doc.text(
        `${postPart}${postPart && psPart ? ', ' : ''}${psPart}, ${districtPart}${districtPart ? ', ' : ''}${countryPart}.`,
        margin + 2,
        curY + 14.5
      );
    } else if (applicantAddress.length > 52) {
      doc.text(applicantAddress.slice(52, 104), margin + 2, curY + 14.5);
    }
  }

  if (bankName) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.8);
    doc.text(
      `A/C NO:- ${bankName}${bankBranch ? ', ' + bankBranch : ''}`,
      margin + 2,
      curY + 22
    );
    if (bankAddress) {
      doc.text(bankAddress.slice(0, 52), margin + 2, curY + 25.5);
      if (bankAddress.length > 52) {
        doc.text(bankAddress.slice(52, 104), margin + 2, curY + 29);
      }
    }
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text(
    `EXPORT SC/LC NO. ${data.exportScLcNo || ''} Dt.${data.exportScLcDate || ''}`,
    midX + 2,
    curY + 4
  );
  doc.line(midX, curY + 6, pageWidth - margin, curY + 6);
  doc.text(`BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`, midX + 2, curY + 10);
  doc.line(midX, curY + 12, pageWidth - margin, curY + 12);
  doc.text(`BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`, midX + 2, curY + 16);
  doc.line(midX, curY + 18, pageWidth - margin, curY + 18);
  doc.text(`IRC NO.${data.exporter?.ircNo || ''}`, midX + 2, curY + 22);
  doc.line(midX, curY + 24, pageWidth - margin, curY + 24);
  doc.text(
    `T/R NO.: ${data.truckReceiptNo || ''} Date.${data.truckReceiptDate || ''}`,
    midX + 2,
    curY + 29
  );

  curY += r2H;

  // Row 3: Port of loading & Final destination
  doc.line(margin, curY + 6, pageWidth - margin, curY + 6);
  doc.line(midX - 10, curY, midX - 10, curY + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('PORT OF LOADING', margin + 2, curY + 4);
  doc.text(`: ${data.portOfLoading || "BENEFICIARY'S FACTORY"}`, margin + 35, curY + 4);
  doc.text(`FINAL DESTINATION : ${data.finalDestination || "OPENER'S FACTORY SITE"}`, midX - 8, curY + 4);

  curY += 6;

  // Row 4: Carrier & Sailing
  doc.line(margin, curY + 6, pageWidth - margin, curY + 6);
  doc.line(midX - 10, curY, midX - 10, curY + 6);
  doc.text(`CARRIER : ${data.carrier || 'BY TRUCK'}`, margin + 2, curY + 4);
  doc.text('SAILING ON OR ABOUT :', midX - 8, curY + 4);

  curY += 6;

  // Row 5: CFR Terms
  doc.line(margin, curY + 6, pageWidth - margin, curY + 6);
  doc.text(data.terms || "CFR OPENER'S FACTORY SITE", margin + 2, curY + 4);

  curY += 6;

  // Items table
  const tableRows = items.map((it) => [
    String(it.itemNo),
    it.particulars,
    it.ctnNo || '',
    `${it.quantity.toLocaleString()} ${it.unit}`,
    `$${it.unitPrice.toFixed(4)}`,
    `$ ${it.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
  ]);

  autoTable(doc, {
    startY: curY,
    margin: { left: margin, right: margin },
    head: [['S/L NO.', 'PARTICULARS', 'Ctn/No.', 'Qty/Gyds/Dzn/Pcs.', 'Unit Price', 'Amount USD.']],
    body: [['', data.itemsCategory || 'GARMENTS ACCESSORIES', '', '', '', ''], ...tableRows],
    theme: 'grid',
    headStyles: {
      fillColor: [255, 255, 255],
      textColor: [0, 0, 0],
      fontSize: 7.2,
      fontStyle: 'bold',
      lineWidth: 0.3,
      lineColor: [0, 0, 0],
    },
    columnStyles: {
      0: { cellWidth: 14, halign: 'center' },
      1: { cellWidth: 78, halign: 'left' },
      2: { cellWidth: 22, halign: 'center' },
      3: { cellWidth: 26, halign: 'right' },
      4: { cellWidth: 20, halign: 'right' },
      5: { cellWidth: 26, halign: 'right' },
    },
    styles: {
      fontSize: 6.8,
      textColor: [0, 0, 0],
      lineColor: [0, 0, 0],
      lineWidth: 0.3,
      cellPadding: 1.5,
    },
  });

  const finalY = (doc as any).lastAutoTable.finalY;

  // Total Row
  doc.rect(margin, finalY, contentWidth, 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('TOTAL :', margin + 4, finalY + 4.2);
  doc.text(
    `${(data.totalQuantity || 0).toLocaleString()} ${data.totalQuantityUnit || 'Pcs'}`,
    margin + 114,
    finalY + 4.2,
    { align: 'right' }
  );
  doc.text(
    `$${(data.totalAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
    pageWidth - margin - 3,
    finalY + 4.2,
    { align: 'right' }
  );

  // In words
  doc.rect(margin, finalY + 6, contentWidth, 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text(data.amountInWords || '', margin + 14, finalY + 10.2);

  // Origin declaration
  doc.rect(margin, finalY + 12, contentWidth, 5.5);
  doc.setFontSize(6.5);
  doc.text(
    'THIS IS TO CERTIFY THAT THE MERCHANDISE DELIVERED/SUPPLIED TO THE ABOVE MENTIONED BUYERS ARE OF BANGALDESH ORIGIN.',
    pageWidth / 2,
    finalY + 15.8,
    { align: 'center' }
  );

  // Signatures
  const sigY = pageHeight - margin - 22;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('FOR,', margin + 15, sigY);
  doc.text(data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.', margin + 15, sigY + 4);
  doc.text('AUTHORIZED SIGNATURE', margin + 15, pageHeight - margin - 5);
}

// ==========================================
// 2. PAGE 2: PACKING LIST
// ==========================================
export function renderPackingList(
  doc: jsPDF,
  data: TradeDocumentData,
  margin = 12,
  pageWidth = 210,
  pageHeight = 297
) {
  const contentWidth = pageWidth - margin * 2;
  const items = data.items || [];

  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.6);
  doc.rect(margin, margin, contentWidth, pageHeight - margin * 2 - 18);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(0, 0, 0);
  doc.text(
    data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.',
    pageWidth / 2,
    margin + 7,
    { align: 'center' }
  );

  doc.setFontSize(12);
  doc.text('PACKING LIST', pageWidth / 2, margin + 13, { align: 'center' });

  doc.setLineWidth(0.4);
  doc.line(margin, margin + 15, pageWidth - margin, margin + 15);

  let curY = margin + 15;
  const midX = margin + contentWidth * 0.52;

  // Shipper / Delivery Challan
  doc.line(margin, curY + 15, pageWidth - margin, curY + 15);
  doc.line(midX, curY, midX, curY + 15);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('SHIPPER/ EXPORTER', margin + 2, curY + 4);
  doc.text(data.exporter?.name || '', margin + 2, curY + 7.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text('1,NO SADHU MADBOR ROAD,MAMUDPUR,', margin + 2, curY + 10.5);
  doc.text('BHUIGHAR,FATULLAH,NARAYONGONJ.', margin + 2, curY + 13.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('DELIVERY CHALLAN NO.', midX + 2, curY + 4);
  doc.setFont('helvetica', 'normal');
  doc.text(data.challanNo || '', midX + 45, curY + 4);
  doc.text(`Date.${data.challanDate || ''}`, midX + 65, curY + 4);

  doc.line(midX, curY + 7.5, pageWidth - margin, curY + 7.5);
  doc.setFont('helvetica', 'bold');
  doc.text(`L/C NO. ${data.lcNo || ''} Date.${data.lcDate || ''}`, midX + 2, curY + 12);

  curY += 15;

  // Consignee & Details
  const r2H = 34;
  doc.line(margin, curY + r2H, pageWidth - margin, curY + r2H);
  doc.line(midX, curY, midX, curY + r2H);

  const {
    applicantName,
    applicantAddress,
    postPart,
    psPart,
    bankName,
    bankBranch,
    bankAddress,
  } = getPartyAndBankInfo(data);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('CONSIGNEE OR ORDER :', margin + 2, curY + 4);
  doc.text('TO THE ORDER OF :', margin + 2, curY + 7.5);
  doc.text(applicantName, margin + 2, curY + 11);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text(applicantAddress.slice(0, 52), margin + 2, curY + 14.5);
  if (postPart || psPart) {
    doc.text(`${postPart}${postPart && psPart ? ', ' : ''}${psPart}`, margin + 2, curY + 18);
  } else if (applicantAddress.length > 52) {
    doc.text(applicantAddress.slice(52, 104), margin + 2, curY + 18);
  }

  if (bankName) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.8);
    doc.text(
      `A/C NO:- ${bankName}${bankBranch ? ', ' + bankBranch : ''}`,
      margin + 2,
      curY + 22
    );
    if (bankAddress) {
      doc.text(bankAddress.slice(0, 52), margin + 2, curY + 25.5);
      if (bankAddress.length > 52) {
        doc.text(bankAddress.slice(52, 104), margin + 2, curY + 29);
      }
    }
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text(
    `EXPORT SC/LC NO. ${data.exportScLcNo || ''} Dt.${data.exportScLcDate || ''}`,
    midX + 2,
    curY + 4
  );
  doc.line(midX, curY + 6, pageWidth - margin, curY + 6);
  doc.text(`BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`, midX + 2, curY + 10);
  doc.line(midX, curY + 12, pageWidth - margin, curY + 12);
  doc.text(`BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`, midX + 2, curY + 16);
  doc.line(midX, curY + 18, pageWidth - margin, curY + 18);
  doc.text(`IRC NO.${data.exporter?.ircNo || ''}`, midX + 2, curY + 22);
  doc.line(midX, curY + 24, pageWidth - margin, curY + 24);
  doc.text(
    `T/R NO.: ${data.truckReceiptNo || ''} Date.${data.truckReceiptDate || ''}`,
    midX + 2,
    curY + 29
  );

  curY += r2H;

  // Loading / Final destination
  doc.line(margin, curY + 6, pageWidth - margin, curY + 6);
  doc.line(midX - 10, curY, midX - 10, curY + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text(`PORT OF LOADING : ${data.portOfLoading || "BENEFICIARY'S FACTORY"}`, margin + 2, curY + 4);
  doc.text(`FINAL DESTINATION : ${data.finalDestination || "OPENER'S FACTORY SITE"}`, midX - 8, curY + 4);

  curY += 6;

  // Marks & Numbers row
  doc.line(margin, curY + 6, pageWidth - margin, curY + 6);
  doc.text('MARKS & NUMBERS', margin + 2, curY + 4);

  curY += 6;

  // Table
  const plRows = items.map((it) => [
    String(it.itemNo),
    it.particulars,
    it.eachPkg || '3000 Pkg',
    `${it.quantity.toLocaleString()} ${it.unit}`,
    `${it.quantity.toLocaleString()} ${it.unit}`,
  ]);

  autoTable(doc, {
    startY: curY,
    margin: { left: margin, right: margin },
    head: [['SL.NO.', 'PARTICULARS', 'EACH', 'QUANTITY', 'TOTAL QNTY (IN Yds./Mtr/Dzn/Pcs)']],
    body: [['', data.itemsCategory || 'GARMENTS ACCESSORIES', '', '', ''], ...plRows],
    theme: 'grid',
    headStyles: {
      fillColor: [255, 255, 255],
      textColor: [0, 0, 0],
      fontSize: 7.2,
      fontStyle: 'bold',
      lineWidth: 0.3,
      lineColor: [0, 0, 0],
    },
    columnStyles: {
      0: { cellWidth: 14, halign: 'center' },
      1: { cellWidth: 84, halign: 'left' },
      2: { cellWidth: 26, halign: 'center' },
      3: { cellWidth: 28, halign: 'right' },
      4: { cellWidth: 34, halign: 'right' },
    },
    styles: {
      fontSize: 6.8,
      textColor: [0, 0, 0],
      lineColor: [0, 0, 0],
      lineWidth: 0.3,
      cellPadding: 1.5,
    },
  });

  const finalY = (doc as any).lastAutoTable.finalY;

  // Total row
  doc.rect(margin, finalY, contentWidth, 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text(data.totalPkgCount || '30000 Pkg', margin + 110, finalY + 4.2, { align: 'center' });
  doc.text(
    `${(data.totalQuantity || 0).toLocaleString()} ${data.totalQuantityUnit || 'Pcs'}`,
    margin + 140,
    finalY + 4.2,
    { align: 'right' }
  );
  doc.text(
    `${(data.totalQuantity || 0).toLocaleString()} ${data.totalQuantityUnit || 'Pcs'}`,
    pageWidth - margin - 3,
    finalY + 4.2,
    { align: 'right' }
  );

  // Signature
  const sigY = finalY + 12;
  doc.text('FOR', margin + 115, sigY);
  doc.text(data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.', margin + 115, sigY + 4);
  doc.text('AUTHORIZED SIGNATURE', margin + 115, sigY + 18);

  drawStandardFooter(doc, data, pageWidth, pageHeight, margin);
}

// ==========================================
// 3. PAGE 3: DELIVERY CHALAN/TRUCK CHALAN
// ==========================================
export function renderDeliveryChallan(
  doc: jsPDF,
  data: TradeDocumentData,
  margin = 12,
  pageWidth = 210,
  pageHeight = 297
) {
  const contentWidth = pageWidth - margin * 2;
  const items = data.items || [];

  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.6);
  doc.rect(margin, margin, contentWidth, pageHeight - margin * 2 - 18);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(
    data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.',
    pageWidth / 2,
    margin + 7,
    { align: 'center' }
  );

  doc.setFontSize(11);
  doc.text('DELIVERY CHALAN/TRUCK CHALAN', pageWidth / 2, margin + 13, { align: 'center' });

  doc.setLineWidth(0.4);
  doc.line(margin, margin + 15, pageWidth - margin, margin + 15);

  let curY = margin + 15;
  const midX = margin + contentWidth * 0.48;

  doc.line(margin, curY + 15, pageWidth - margin, curY + 15);
  doc.line(midX, curY, midX, curY + 15);

  doc.setFontSize(7.2);
  doc.text('SHIPPER/EXPORTER', margin + 2, curY + 4);
  doc.text(data.exporter?.name || '', margin + 2, curY + 7.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.text('1,NO SADHU MADBOR ROAD,MAMUDPUR,', margin + 2, curY + 10.5);
  doc.text('BHUIGHAR,FATULLAH,NARAYONGONJ.', margin + 2, curY + 13.5);

  doc.setFont('helvetica', 'bold');
  doc.text('DELIVERY CHALLAN NO.', midX + 2, curY + 4);
  doc.setFont('helvetica', 'normal');
  doc.text(data.challanNo || '', midX + 45, curY + 4);
  doc.text(`Date.${data.challanDate || ''}`, midX + 65, curY + 4);

  doc.line(midX, curY + 7.5, pageWidth - margin, curY + 7.5);
  doc.setFont('helvetica', 'bold');
  doc.text(`L/C NO. ${data.lcNo || ''} Date.${data.lcDate || ''}`, midX + 2, curY + 12);

  curY += 15;

  // Consignee details
  const r2H = 34;
  doc.line(margin, curY + r2H, pageWidth - margin, curY + r2H);
  doc.line(midX, curY, midX, curY + r2H);

  const {
    applicantName,
    applicantAddress,
    postPart,
    psPart,
    districtPart,
    bankName,
    bankBranch,
    bankAddress,
  } = getPartyAndBankInfo(data);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('CONSIGNEE OR ORDER :', margin + 2, curY + 4);
  doc.text('TO THE ORDER OF', margin + 2, curY + 7.5);

  if (bankName) {
    doc.setFontSize(6.8);
    doc.text(
      `A/C NO:- ${bankName}${bankBranch ? ', ' + bankBranch : ''}`,
      margin + 2,
      curY + 11
    );
    if (bankAddress) {
      doc.text(bankAddress.slice(0, 52), margin + 2, curY + 14.5);
    }
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.2);
  doc.text('NOTIFY PARTY/APPLICANT.:', margin + 2, curY + 21);
  doc.text(applicantName, margin + 2, curY + 24.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.text(applicantAddress.slice(0, 52), margin + 2, curY + 28);
  if (postPart || psPart) {
    doc.text(
      `${postPart}${postPart && psPart ? ', ' : ''}${psPart}, ${districtPart}`,
      margin + 2,
      curY + 31.5
    );
  } else if (applicantAddress.length > 52) {
    doc.text(applicantAddress.slice(52, 104), margin + 2, curY + 31.5);
  }

  doc.setFont('helvetica', 'bold');
  doc.text(
    `EXPORT SC/LC NO. ${data.exportScLcNo || ''} Dt.${data.exportScLcDate || ''}`,
    midX + 2,
    curY + 4
  );
  doc.line(midX, curY + 6, pageWidth - margin, curY + 6);
  doc.text(`BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`, midX + 2, curY + 10);
  doc.line(midX, curY + 12, pageWidth - margin, curY + 12);
  doc.text(`BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`, midX + 2, curY + 16);
  doc.line(midX, curY + 18, pageWidth - margin, curY + 18);
  doc.text(`IRC NO.${data.exporter?.ircNo || ''}`, midX + 2, curY + 22);
  doc.line(midX, curY + 24, pageWidth - margin, curY + 24);
  doc.text(
    `T/R NO.: ${data.truckReceiptNo || ''} Date.${data.truckReceiptDate || ''}`,
    midX + 2,
    curY + 27.5
  );
  doc.text(`SHIPMENT PER : ${data.carrier || 'BY TRUCK'}`, midX + 2, curY + 31.5);

  curY += r2H;

  // Loading / Final destination
  doc.line(margin, curY + 6, pageWidth - margin, curY + 6);
  doc.line(midX - 10, curY, midX - 10, curY + 6);
  doc.setFont('helvetica', 'bold');
  doc.text(`PORT OF LOADING : ${data.portOfLoading || "BENEFICIARY'S FACTORY"}`, margin + 2, curY + 4);
  doc.text(`FINAL DESTINATION : ${data.finalDestination || "OPENER'S FACTORY SITE"}`, midX - 8, curY + 4);

  curY += 6;

  // Table
  const dcRows = items.map((it) => [
    String(it.itemNo),
    it.particulars,
    it.eachPkg || '1000 Pkg',
    `${it.quantity.toLocaleString()} ${it.unit}`,
    `${it.quantity.toLocaleString()} ${it.unit}`,
  ]);

  autoTable(doc, {
    startY: curY,
    margin: { left: margin, right: margin },
    head: [['SL NO', 'PARTICULARS', 'EACH', 'Quantity', 'Total/Quantity/Gyd/Yds/Dzn./Pcs.']],
    body: [['', data.itemsCategory || 'GARMENTS ACCESSORIES', '', '', ''], ...dcRows],
    theme: 'grid',
    headStyles: {
      fillColor: [255, 255, 255],
      textColor: [0, 0, 0],
      fontSize: 7.2,
      fontStyle: 'bold',
      lineWidth: 0.3,
      lineColor: [0, 0, 0],
    },
    columnStyles: {
      0: { cellWidth: 14, halign: 'center' },
      1: { cellWidth: 84, halign: 'left' },
      2: { cellWidth: 26, halign: 'center' },
      3: { cellWidth: 28, halign: 'right' },
      4: { cellWidth: 34, halign: 'right' },
    },
    styles: {
      fontSize: 6.8,
      textColor: [0, 0, 0],
      lineColor: [0, 0, 0],
      lineWidth: 0.3,
      cellPadding: 1.5,
    },
  });

  const finalY = (doc as any).lastAutoTable.finalY;

  // Total row
  doc.rect(margin, finalY, contentWidth, 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text(data.totalPkgCount || '8000 Pkg', margin + 110, finalY + 4.2, { align: 'center' });
  doc.text(
    `${(data.totalQuantity || 0).toLocaleString()} ${data.totalQuantityUnit || 'Pcs'}`,
    margin + 140,
    finalY + 4.2,
    { align: 'right' }
  );
  doc.text(
    `${(data.totalQuantity || 0).toLocaleString()} ${data.totalQuantityUnit || 'Pcs'}`,
    pageWidth - margin - 3,
    finalY + 4.2,
    { align: 'right' }
  );

  // Signature
  const sigY = finalY + 12;
  doc.text('For,', margin + 115, sigY);
  doc.text(data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.', margin + 115, sigY + 4);
  doc.text('AUTHORIZED SIGNATURE', margin + 115, sigY + 18);

  drawStandardFooter(doc, data, pageWidth, pageHeight, margin);
}

// ==========================================
// 4. PAGE 4: BILL OF EXCHANGE (FIRST & SECOND)
// ==========================================
export function renderBillOfExchange(
  doc: jsPDF,
  data: TradeDocumentData,
  margin = 12,
  pageWidth = 210
) {
  const renderBillPart = (partNum: 1 | 2, startTopY: number) => {
    // 1. Center Title "BILL OF EXCHANGE"
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.setTextColor(0, 0, 0);
    doc.text('BILL OF EXCHANGE', pageWidth / 2 + 5, startTopY, { align: 'center' });

    // 2. Vertical Box on the Left
    const boxStartY = startTopY + 8;
    const stripW = 12;
    const stripH = 92;
    const boxLeft = margin + 2;

    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.4);
    doc.rect(boxLeft, boxStartY, stripW, stripH);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.', boxLeft + 4.8, boxStartY + stripH - 6, {
      angle: 90,
    });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(5.8);
    doc.text(
      '1,NO.SADHU MADBOR,ROAD,MAMUDPUR,BHUIGHAR,FATULLAH, NARA YONGONJ.',
      boxLeft + 9.2,
      boxStartY + stripH - 6,
      { angle: 90 }
    );

    // 3. Content on the Right of vertical box
    const cX = boxLeft + stripW + 5;
    const rightColX = cX + 78;

    // Large 3D Styled Numeral "1" or "2" on top right
    const numX = pageWidth - margin - 22;
    const numY = boxStartY + 14;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(40);
    doc.setTextColor(190, 215, 240);
    doc.text(String(partNum), numX + 0.8, numY + 0.8);
    doc.setTextColor(52, 115, 175);
    doc.text(String(partNum), numX, numY);
    doc.setTextColor(0, 0, 0);

    // P/I No & Date
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.8);
    doc.text('P/I NO.:', cX, boxStartY + 4);
    doc.setFont('helvetica', 'bold');
    doc.text(data.piNo || '', cX + 22, boxStartY + 4);
    doc.text(`Date.${data.piDate || ''}`, cX + 65, boxStartY + 4);

    // Exchange for (USD)
    doc.setFont('helvetica', 'bold');
    doc.text('EXCHANGE FOR (USD):', cX, boxStartY + 10.5);
    doc.text(
      `$${(data.totalAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      cX + 52,
      boxStartY + 10.5
    );

    // At Sight paragraph (Italic)
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    if (partNum === 1) {
      doc.text(
        'At Sight of this FIRST Bill of Exchange (SECOND of the same tenor and date being-unpaid)',
        cX,
        boxStartY + 17
      );
    } else {
      doc.text(
        'At Sight of this SECOND Bill of Exchange (FIRST of the same tenor and date being-unpaid)',
        cX,
        boxStartY + 17
      );
    }

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text(
      `pay to the order of "${data.negotiatingBank?.name || 'SOUTHEAST BANK PLC.'},${data.negotiatingBank?.branch || 'MOUCHAK BRANCH'},`,
      cX,
      boxStartY + 21.5
    );
    doc.text(
      `${data.negotiatingBank?.city || 'DHAKA,BANGLADESH.'}"`,
      cX,
      boxStartY + 25.5
    );
    doc.text('The sum of U.S. Dollar', cX + 56, boxStartY + 25.5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text(data.amountInWords || '', cX + 3, boxStartY + 30);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.2);
    doc.text('Value Received Against Shipment of AS PER DELIVERY CHALLAN NO.:', cX, boxStartY + 35);
    doc.text(data.challanNo || '', cX, boxStartY + 39.5);
    doc.text(`Date.${data.challanDate || ''}`, cX + 24, boxStartY + 39.5);

    // Split 2 Columns below
    const lowerY = boxStartY + 44.5;
    doc.text('to the account of and issued by :', cX, lowerY);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.2);
    doc.text(`L/C NO. ${data.lcNo || ''}`, rightColX, lowerY);
    doc.text(`Date.${data.lcDate || ''}`, rightColX + 44, lowerY);
    doc.text(
      `EXPORT SC/LC NO. ${data.exportScLcNo || ''} Dt.${data.exportScLcDate || ''}`,
      rightColX,
      lowerY + 4
    );
    doc.text(`BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`, rightColX, lowerY + 8);
    doc.text(`BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`, rightColX, lowerY + 12);
    doc.text(`IRC NO.${data.exporter?.ircNo || ''}`, rightColX, lowerY + 16);

    const {
      applicantName,
      applicantAddress,
      postPart,
      psPart,
      districtPart,
      countryPart,
      bankName,
      bankBranch,
      bankAddress,
    } = getPartyAndBankInfo(data);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.8);
    doc.text('TO :', cX, lowerY + 10.5);
    doc.text(applicantName, cX, lowerY + 14.5);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.8);
    doc.text(applicantAddress.slice(0, 50), cX, lowerY + 18.5);
    if (postPart || psPart) {
      doc.text(`${postPart}${postPart && psPart ? ', ' : ''}${psPart},`, cX, lowerY + 22);
      doc.text(`${districtPart}${districtPart ? ', ' : ''}${countryPart}.`, cX, lowerY + 25.5);
    } else if (applicantAddress.length > 50) {
      doc.text(applicantAddress.slice(50, 100), cX, lowerY + 22);
    }

    if (bankName) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.8);
      doc.text(
        `A/C NO:- ${bankName}${bankBranch ? ', ' + bankBranch : ''}`,
        cX,
        lowerY + 29.5
      );
      if (bankAddress) {
        doc.text(bankAddress.slice(0, 48), cX, lowerY + 33);
        if (bankAddress.length > 48) {
          doc.text(bankAddress.slice(48, 96), cX, lowerY + 36.5);
        }
      }
    }

    // Authorized Signature
    const sigY = lowerY + 24;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.2);
    doc.text('For', rightColX + 8, sigY);
    doc.text(data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.', rightColX + 8, sigY + 4);
    doc.setFontSize(6.8);
    doc.text('AUTHORIZED SIGNATURE', rightColX + 8, sigY + 14);
  };

  renderBillPart(1, margin + 8);
  renderBillPart(2, margin + 138);
}

// ==========================================
// 5. PAGE 5: CERTIFICATE OF ORIGIN
// ==========================================
export function renderCertificateOfOrigin(
  doc: jsPDF,
  data: TradeDocumentData,
  margin = 12,
  pageWidth = 210
) {
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(0, 0, 0);
  doc.text(
    data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.',
    pageWidth / 2,
    margin + 10,
    { align: 'center' }
  );

  doc.setFontSize(12);
  doc.text('CERTIFICATE OF ORIGIN', pageWidth / 2, margin + 18, { align: 'center' });
  doc.setLineWidth(0.4);
  doc.line(pageWidth / 2 - 38, margin + 19, pageWidth / 2 + 38, margin + 19);

  let curY = margin + 30;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Date.${data.invoiceDate || ''}`, margin + 5, curY);

  curY += 8;
  doc.setFont('helvetica', 'bold');
  doc.text("1 Supplier's Name", margin + 5, curY);
  curY += 5;
  doc.text(`2 ${data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.'}`, margin + 5, curY);
  curY += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.text('1,NO SADHU MADBOR ROAD,MAMUDPUR,', margin + 9, curY);
  curY += 4;
  doc.text('BHUIGHAR,FATULLAH,NARAYONGONJ.', margin + 9, curY);

  curY += 6;
  doc.setFont('helvetica', 'bold');
  doc.text("3 Applicant /Buyer's Name", margin + 5, curY);
  curY += 5;

  const { applicantName, applicantAddress, postPart, psPart, districtPart, countryPart } =
    getPartyAndBankInfo(data);

  doc.text(`4 ${applicantName}`, margin + 5, curY);
  curY += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.text(`5 ${applicantAddress}`, margin + 5, curY);
  curY += 4;
  if (postPart || psPart) {
    doc.text(`6 ${postPart}, ${psPart},`, margin + 5, curY);
    curY += 4;
    doc.text(`7 ${districtPart}, ${countryPart}.`, margin + 5, curY);
  }

  curY += 8;
  doc.setFont('helvetica', 'normal');
  doc.text(`L/C NO. ${data.lcNo || ''} Date.${data.lcDate || ''}`, margin + 9, curY);
  curY += 4.5;
  doc.text(
    `EXPORT SC/LC NO. ${data.exportScLcNo || ''} Dt.${data.exportScLcDate || ''}`,
    margin + 9,
    curY
  );
  curY += 4.5;
  doc.text(`BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`, margin + 9, curY);
  curY += 4.5;
  doc.text(`BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`, margin + 9, curY);
  curY += 4.5;
  doc.text(`IRC NO.${data.exporter?.ircNo || ''}`, margin + 9, curY);

  curY += 9;
  const drawItemLine = (num: string, label: string, val: string) => {
    doc.setFont('helvetica', 'bold');
    doc.text(num, margin + 5, curY);
    doc.setFont('helvetica', 'normal');
    doc.text(label, margin + 14, curY);
    doc.text(':', margin + 65, curY);
    doc.setFont('helvetica', 'bold');
    doc.text(val, margin + 70, curY);
    curY += 6;
  };

  drawItemLine(
    '8',
    'Quantity of Goods',
    `${(data.totalQuantity || 0).toLocaleString()} ${data.totalQuantityUnit || 'Pcs'}`
  );
  drawItemLine(
    '9',
    'Invoice No. and Date',
    `${data.invoiceNo || ''} Date.${data.invoiceDate || ''}`
  );
  drawItemLine(
    '10',
    'Truck Receip No. and Date.',
    `T/R NO.: ${data.truckReceiptNo || ''} Date.${data.truckReceiptDate || ''}`
  );
  drawItemLine(
    '11',
    'Invoice Value',
    `$${(data.totalAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  );
  drawItemLine(
    '12',
    "Applicant's Bin",
    `BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`
  );
  drawItemLine(
    '13',
    'Bank Vat Reg. No.',
    `BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`
  );

  curY += 6;
  doc.setFont('helvetica', 'normal');
  doc.text(
    'This is to Certify That Merchandise Delivered/Supplied to the above Mentioned',
    margin + 5,
    curY
  );
  curY += 4.5;
  doc.text('Buyers Are of Bangladesh Origin', margin + 5, curY);

  curY += 15;
  doc.setFont('helvetica', 'bold');
  doc.text(`For : ${data.exporter?.name || 'Seven Classic Industries Ltd.'}`, margin + 5, curY);
  curY += 20;
  doc.text('Authorized Signature', margin + 5, curY);
}

// ==========================================
// 6. PAGE 6: BENEFICIARY'S CERTIFICATE
// ==========================================
export function renderBeneficiaryCertificate(
  doc: jsPDF,
  data: TradeDocumentData,
  margin = 12,
  pageWidth = 210
) {
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(17);
  doc.setTextColor(0, 0, 0);
  doc.text(
    data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.',
    pageWidth / 2,
    margin + 12,
    { align: 'center' }
  );

  doc.setLineWidth(0.5);
  doc.line(pageWidth / 2 - 58, margin + 14, pageWidth / 2 + 58, margin + 14);

  doc.setFontSize(11);
  doc.text("BENEFICIARY'S CERTIFICATE", pageWidth / 2, margin + 24, { align: 'center' });
  doc.line(pageWidth / 2 - 32, margin + 25.5, pageWidth / 2 + 32, margin + 25.5);

  let curY = margin + 38;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`Date.${data.invoiceDate || ''}`, margin + 5, curY);

  curY += 10;
  doc.text(`This is to certify that the goods shipped against P/I No. ${data.piNo || ''}`, margin + 5, curY);
  curY += 5;
  doc.text(`Date.${data.piDate || ''}`, margin + 5, curY);
  curY += 5;
  doc.text(`L/C NO. ${data.lcNo || ''} Date.${data.lcDate || ''}`, margin + 5, curY);
  curY += 5;
  doc.text(
    `EXPORT SC/LC NO. ${data.exportScLcNo || ''} Dt.${data.exportScLcDate || ''}`,
    margin + 5,
    curY
  );
  curY += 5;
  doc.text(`BENEFICIARY BIN NO.${data.exporter?.beneficiaryBin || ''}`, margin + 5, curY);
  curY += 5;
  doc.text(`BANK VAT REG.NO. ${data.exporter?.bankVatRegNo || ''}`, margin + 5, curY);
  curY += 5;
  doc.text(`IRC NO.${data.exporter?.ircNo || ''}`, margin + 5, curY);

  curY += 6;
  doc.text('Is Manufactured by us and is Completely of Bangladesh Origin.', margin + 5, curY);

  curY += 30;
  doc.setFont('helvetica', 'bold');
  doc.text(`FOR, ${data.exporter?.name || 'SEVEN CLASSIC INDUSTRIES LTD.'}`, margin + 5, curY);
  curY += 25;
  doc.text('AUTHORIZED SIGNATURE', margin + 5, curY);
}

// Generate Individual Document PDF
export function generateTradePdf(
  data: TradeDocumentData,
  templateType: DocTemplateType
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const margin = 12;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  if (templateType === 'COMMERCIAL_INVOICE') {
    renderCommercialInvoice(doc, data, margin, pageWidth, pageHeight);
  } else if (templateType === 'PACKING_LIST') {
    renderPackingList(doc, data, margin, pageWidth, pageHeight);
  } else if (templateType === 'DELIVERY_CHALLAN') {
    renderDeliveryChallan(doc, data, margin, pageWidth, pageHeight);
  } else if (templateType === 'BILL_OF_EXCHANGE') {
    renderBillOfExchange(doc, data, margin, pageWidth);
  } else if (templateType === 'CERTIFICATE_OF_ORIGIN') {
    renderCertificateOfOrigin(doc, data, margin, pageWidth);
  } else if (templateType === 'BENEFICIARY_CERT') {
    renderBeneficiaryCertificate(doc, data, margin, pageWidth);
  }

  return doc;
}

// GENERATE FULL 6-PAGE SET IN A SINGLE PDF FILE
export function generateFull6PageTradeSetPdf(data: TradeDocumentData): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const margin = 12;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Page 1: COMMERCIAL INVOICE
  renderCommercialInvoice(doc, data, margin, pageWidth, pageHeight);

  // Page 2: PACKING LIST
  doc.addPage();
  renderPackingList(doc, data, margin, pageWidth, pageHeight);

  // Page 3: DELIVERY CHALAN
  doc.addPage();
  renderDeliveryChallan(doc, data, margin, pageWidth, pageHeight);

  // Page 4: BILL OF EXCHANGE (FIRST & SECOND)
  doc.addPage();
  renderBillOfExchange(doc, data, margin, pageWidth);

  // Page 5: CERTIFICATE OF ORIGIN
  doc.addPage();
  renderCertificateOfOrigin(doc, data, margin, pageWidth);

  // Page 6: BENEFICIARY'S CERTIFICATE
  doc.addPage();
  renderBeneficiaryCertificate(doc, data, margin, pageWidth);

  return doc;
}
