import React from 'react';
import { MaterialItem } from '../types';
import { Lock, FileText, Sparkles } from 'lucide-react';

interface TrackerDashboardProps {
  materials: MaterialItem[];
  isAdminLoggedIn: boolean;
  onOpenAdmin: () => void;
  onEditMaterial: (mat: MaterialItem) => void;
  onDeleteMaterial: (id: string) => void;
  onQuickOpenDocGen: () => void;
}

export const TrackerDashboard: React.FC<TrackerDashboardProps> = ({
  materials,
  isAdminLoggedIn,
  onOpenAdmin,
  onEditMaterial,
  onDeleteMaterial,
  onQuickOpenDocGen,
}) => {
  // Footer metrics calculation
  let totalRemainingKg = 0;
  let totalInventoryValue = 0;
  let lowBalanceCount = 0;

  materials.forEach((m) => {
    const rem = Number(m.remainingBalance) || 0;
    const max = Number(m.maxQty) || 0;
    const price = Number(m.unitPrice) || 0;
    totalRemainingKg += rem;
    totalInventoryValue += rem * price;
    const pct = max > 0 ? (rem / max) * 100 : 0;
    if (pct < 20) {
      lowBalanceCount++;
    }
  });

  return (
    <div className="bg-[#13161c] rounded-xl p-6 sm:p-8 shadow-[0_10px_30px_rgba(0,0,0,0.5)] border border-[#2c313d] text-white">
      {/* Top Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-2xl sm:text-3xl lg:text-[34px] font-bold text-[#8a92a6] tracking-wider uppercase">
            Seven Classic Ind. Ltd.
          </div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white mt-1">
            Live Raw Material Balance Tracker
          </h1>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onQuickOpenDocGen}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wide transition shadow-lg shadow-sky-900/40"
          >
            <Sparkles className="w-4 h-4 text-sky-200" />
            <span>Generate LC / PI Documents</span>
          </button>
        </div>
      </div>

      {/* Table Column Titles (Desktop) */}
      <div className="hidden lg:grid grid-cols-[210px_minmax(180px,1fr)_140px_110px_130px_90px] gap-4 items-center pb-3 mb-4 border-b border-[#2c313d] text-[#8a92a6] text-xs font-bold uppercase tracking-wider">
        <div>Raw Materials</div>
        <div>Balance Level</div>
        <div className="text-right">Remaining Balance</div>
        <div className="text-right">Unit Price</div>
        <div className="text-right">Total Value</div>
        <div className={`text-center ${isAdminLoggedIn ? 'block' : 'hidden'}`}>Action</div>
      </div>

      {/* Materials List */}
      <div className="space-y-6 mb-6">
        {materials.length === 0 ? (
          <div className="text-center text-[#8a92a6] py-10 px-3 border border-dashed border-[#2c313d] rounded-md text-sm">
            No raw materials added yet.
            <br />
            <br />
            Click <strong className="text-white">Admin Panel Access</strong> below to add materials.
          </div>
        ) : (
          materials.map((mat) => {
            const totalKg = Number(mat.maxQty) || 0;
            const remaining = Number(mat.remainingBalance) || 0;
            const unitPrice = Number(mat.unitPrice) || 0;
            const totalValue = remaining * unitPrice;
            let percentage = totalKg > 0 ? (remaining / totalKg) * 100 : 0;
            percentage = Math.max(0, Math.min(100, percentage));

            let progressClass = 'bg-[#2ecc71]'; // green
            let stockClass = 'text-[#2ecc71]'; // good stock green
            if (percentage < 20) {
              progressClass = 'bg-[#e74c3c]'; // red
              stockClass = 'text-[#e74c3c]'; // red
            } else if (percentage < 40) {
              progressClass = 'bg-[#f1c40f]'; // yellow
            }

            return (
              <div
                key={mat.id}
                className="grid grid-cols-1 lg:grid-cols-[210px_minmax(180px,1fr)_140px_110px_130px_90px] gap-3 lg:gap-4 items-center py-3 border-b border-[#2c313d]/60 lg:border-none"
              >
                {/* 1. Raw Material Name */}
                <div className="flex flex-col">
                  <div
                    className={`text-base sm:text-lg font-bold uppercase tracking-tight ${
                      mat.isBlue ? 'text-[#3498db]' : 'text-white'
                    }`}
                  >
                    {mat.name}
                  </div>
                  <div className="text-xs text-[#8a92a6] mt-0.5">
                    Lot / Total: {totalKg.toLocaleString()} {mat.unit}
                  </div>
                </div>

                {/* 2. Progress Bar */}
                <div className="w-full">
                  <div className="bg-[#1a1e26] rounded-full h-3.5 w-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${progressClass}`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>

                {/* 3. Remaining Balance */}
                <div className="lg:text-right">
                  <div className={`text-lg sm:text-xl font-bold leading-tight ${stockClass}`}>
                    {remaining.toLocaleString()} {mat.unit}
                  </div>
                  <div className="text-[11px] text-[#8a92a6] mt-0.5">
                    {(remaining / 1000).toLocaleString(undefined, { maximumFractionDigits: 2 })} TON |{' '}
                    {percentage.toFixed(1)}% remaining
                  </div>
                </div>

                {/* 4. Unit Price */}
                <div className="lg:text-right">
                  <div className="text-lg sm:text-xl font-bold text-white">
                    ${unitPrice.toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </div>
                  <div className="text-[10px] text-[#8a92a6] mt-0.5">per {mat.unit}</div>
                </div>

                {/* 5. Total Value */}
                <div className="lg:text-right">
                  <div className="text-lg sm:text-xl font-bold text-[#2ecc71]">
                    ${totalValue.toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </div>
                  <div className="text-[10px] text-[#8a92a6] mt-0.5">
                    {remaining.toLocaleString()} × ${unitPrice.toFixed(2)}
                  </div>
                </div>

                {/* 6. Admin Actions */}
                <div className={`text-center ${isAdminLoggedIn ? 'block' : 'hidden'}`}>
                  <div className="flex lg:flex-col items-center justify-start lg:justify-center gap-1.5">
                    <button
                      onClick={() => onEditMaterial(mat)}
                      className="px-2.5 py-1 text-xs font-bold rounded bg-[#f39c12] hover:bg-[#d68910] text-white transition"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => onDeleteMaterial(mat.id)}
                      className="px-2.5 py-1 text-xs font-bold rounded bg-[#e74c3c] hover:bg-[#c0392b] text-white transition"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Axis Percentage Labels (Desktop) */}
      <div className="hidden lg:grid grid-cols-[210px_minmax(180px,1fr)_140px_110px_130px_90px] gap-4 mb-8">
        <div />
        <div className="flex justify-between text-[#8a92a6] text-xs px-1">
          <span>20%</span>
          <span>40%</span>
          <span>60%</span>
          <span>80%</span>
          <span>100%</span>
        </div>
        <div />
        <div />
        <div />
        <div />
      </div>

      {/* Footer Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 border-t border-[#2c313d] pt-6 text-center gap-4 sm:gap-0">
        {/* Total Remaining Volume */}
        <div className="sm:border-r border-[#2c313d] px-4">
          <div className="text-xs text-[#8a92a6] uppercase tracking-wider mb-2">
            Remaining Raw Material Volume
          </div>
          <div className="text-2xl font-bold text-white">
            {totalRemainingKg.toLocaleString()} kg /{' '}
            {(totalRemainingKg / 1000).toLocaleString(undefined, { maximumFractionDigits: 2 })} TON
          </div>
        </div>

        {/* Total Inventory Value */}
        <div className="sm:border-r border-[#2c313d] px-4">
          <div className="text-xs text-[#8a92a6] uppercase tracking-wider mb-2">
            Total Inventory Value
          </div>
          <div className="text-2xl font-bold text-[#2ecc71]">
            $
            {totalInventoryValue.toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </div>
        </div>

        {/* Low Balance Warning */}
        <div className="px-4">
          <div className="text-xs text-[#8a92a6] uppercase tracking-wider mb-2">
            Low Balance Warning (&lt; 20%)
          </div>
          <div
            className={`text-2xl font-bold ${
              lowBalanceCount > 0 ? 'text-[#e74c3c]' : 'text-[#2ecc71]'
            }`}
          >
            {lowBalanceCount}
          </div>
        </div>
      </div>

      {/* Admin Trigger Zone */}
      <div className="text-center mt-8 pb-2 flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={onOpenAdmin}
          className="bg-[#242933] border border-[#2c313d] hover:border-[#3498db] hover:bg-[#3498db] text-[#d1d5db] hover:text-white text-xs font-bold px-5 py-2.5 rounded-lg transition shadow-md flex items-center gap-2"
        >
          <Lock className="w-4 h-4" />
          <span>Admin Inventory Panel</span>
        </button>
        <button
          onClick={onQuickOpenDocGen}
          className="bg-sky-950/80 border border-sky-500/50 hover:bg-sky-600 text-sky-200 hover:text-white text-xs font-bold px-5 py-2.5 rounded-lg transition shadow-md flex items-center gap-2"
        >
          <FileText className="w-4 h-4" />
          <span>Go to LC / PI Document Generator</span>
        </button>
      </div>
    </div>
  );
};
