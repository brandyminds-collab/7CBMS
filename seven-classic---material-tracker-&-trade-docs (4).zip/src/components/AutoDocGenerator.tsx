import React, { useState, useRef } from 'react';
import { DocTemplateType, MaterialItem, TradeDocumentData, TradeItem } from '../types';
import { SAMPLE_SEVEN_CLASSIC_DOC } from '../utils/sampleData';
import { generateTradePdf, generateFull6PageTradeSetPdf } from '../utils/pdfGenerator';
import { numberToWordsUSD } from '../utils/numberToWords';
import {
  Upload,
  FileText,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Download,
  Eye,
  RefreshCw,
  Plus,
  Trash2,
  FileCheck,
  Package,
  Layers,
  ArrowRight,
  Zap,
} from 'lucide-react';

interface AutoDocGeneratorProps {
  materials: MaterialItem[];
  onDeductMaterialStock?: (materialId: string, deductQty: number) => void;
  onPreviewDoc: (data: TradeDocumentData, templateType: DocTemplateType) => void;
}

export const AutoDocGenerator: React.FC<AutoDocGeneratorProps> = ({
  materials,
  onDeductMaterialStock,
  onPreviewDoc,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'text' | 'samples'>('upload');
  // Auto-generate upon file upload (enabled by default)
  const [autoGenerateOnUpload, setAutoGenerateOnUpload] = useState<boolean>(true);

  // Dual file states for both LC and PI
  const [lcFile, setLcFile] = useState<File | null>(null);
  const [lcFileBase64, setLcFileBase64] = useState<string>('');
  const [lcFileMimeType, setLcFileMimeType] = useState<string>('');
  const [lcPreviewUrl, setLcPreviewUrl] = useState<string | null>(null);

  const [piFile, setPiFile] = useState<File | null>(null);
  const [piFileBase64, setPiFileBase64] = useState<string>('');
  const [piFileMimeType, setPiFileMimeType] = useState<string>('');
  const [piPreviewUrl, setPiPreviewUrl] = useState<string | null>(null);

  const [textContent, setTextContent] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progressStep, setProgressStep] = useState<string>('');
  const [statusNotification, setStatusNotification] = useState<{
    type: 'success' | 'warning' | 'error';
    msg: string;
  } | null>(null);

  // Active document draft initialized to user's exact sample
  const [currentDraft, setCurrentDraft] = useState<TradeDocumentData>(() => {
    const saved = localStorage.getItem('sevenClassicCurrentDraft');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return SAMPLE_SEVEN_CLASSIC_DOC;
      }
    }
    return SAMPLE_SEVEN_CLASSIC_DOC;
  });

  const [syncSuccessMsg, setSyncSuccessMsg] = useState<string | null>(null);
  const lcInputRef = useRef<HTMLInputElement>(null);
  const piInputRef = useRef<HTMLInputElement>(null);

  // Trigger extraction when files are selected and autoGenerate is on
  const runExtraction = async (
    customLcBase64?: string,
    customLcMime?: string,
    customLcName?: string,
    customPiBase64?: string,
    customPiMime?: string,
    customPiName?: string,
    customText?: string
  ) => {
    const activeLcBase64 = customLcBase64 !== undefined ? customLcBase64 : lcFileBase64;
    const activeLcMime = customLcMime !== undefined ? customLcMime : lcFileMimeType;
    const activeLcName = customLcName !== undefined ? customLcName : lcFile?.name;
    const activePiBase64 = customPiBase64 !== undefined ? customPiBase64 : piFileBase64;
    const activePiMime = customPiMime !== undefined ? customPiMime : piFileMimeType;
    const activePiName = customPiName !== undefined ? customPiName : piFile?.name;
    const activeText = customText !== undefined ? customText : textContent;

    if (!activeLcBase64 && !activePiBase64 && !activeText.trim()) {
      setStatusNotification({
        type: 'error',
        msg: 'Please upload an LC file, PI file, or paste text.',
      });
      return;
    }

    setIsProcessing(true);
    setStatusNotification(null);
    setProgressStep('Analyzing uploaded LC / PI file(s)...');

    const stepTimer1 = setTimeout(() => {
      setProgressStep('Extracting Applicant, Issuing Bank, LC/PI numbers & line items...');
    }, 1200);

    const stepTimer2 = setTimeout(() => {
      setProgressStep('Generating all 6 trade document drafts and calculating sums...');
    }, 2800);

    try {
      const response = await fetch('/api/extract-lc-pi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lcFileBase64: activeLcBase64 || undefined,
          lcMimeType: activeLcMime || undefined,
          lcFileName: activeLcName || undefined,
          piFileBase64: activePiBase64 || undefined,
          piMimeType: activePiMime || undefined,
          piFileName: activePiName || undefined,
          textContent: activeText || undefined,
        }),
      });

      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);

      const resData = await response.json();
      if (resData.success && resData.data) {
        const extracted: TradeDocumentData = {
          ...resData.data,
          id: `draft-${Date.now()}`,
          generatedAt: new Date().toLocaleDateString('en-GB'),
        };

        // Recalculate amount in words if needed
        if (
          extracted.totalAmount > 0 &&
          (!extracted.amountInWords || extracted.amountInWords.includes('ZERO'))
        ) {
          extracted.amountInWords = numberToWordsUSD(extracted.totalAmount);
        }

        // Ensure notify party fallback
        if (!extracted.notifyParty || !extracted.notifyParty.name) {
          extracted.notifyParty = {
            name: extracted.buyer?.name || '',
            address: extracted.buyer?.address || '',
          };
        }

        setCurrentDraft(extracted);
        localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(extracted));

        // Save to archive history
        const historyJson = localStorage.getItem('sevenClassicTradeDocHistory');
        const history = historyJson ? JSON.parse(historyJson) : [];
        history.unshift(extracted);
        localStorage.setItem('sevenClassicTradeDocHistory', JSON.stringify(history.slice(0, 30)));

        setStatusNotification({
          type: 'success',
          msg: `Auto-generation complete! 6 trade documents created for ${extracted.buyer?.name || 'Applicant'} ($${extracted.totalAmount?.toLocaleString()} USD).`,
        });
      } else {
        throw new Error(resData.error || 'Failed to extract document data');
      }
    } catch (err: any) {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      console.error(err);
      setStatusNotification({
        type: 'warning',
        msg: err.message || 'Auto-draft generated using smart commercial parser.',
      });
    } finally {
      setIsProcessing(false);
      setProgressStep('');
    }
  };

  // LC file handler
  const handleLcChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLcFile(file);
    setStatusNotification(null);

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      const mime = file.type || (file.name.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg');
      setLcFileBase64(base64);
      setLcFileMimeType(mime);
      if (file.type.startsWith('image/')) {
        setLcPreviewUrl(URL.createObjectURL(file));
      } else {
        setLcPreviewUrl(null);
      }

      // Auto generate immediately upon file upload if enabled
      if (autoGenerateOnUpload) {
        runExtraction(base64, mime, file.name, piFileBase64, piFileMimeType, piFile?.name);
      }
    };
    reader.readAsDataURL(file);
  };

  // PI file handler
  const handlePiChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPiFile(file);
    setStatusNotification(null);

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      const mime = file.type || (file.name.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg');
      setPiFileBase64(base64);
      setPiFileMimeType(mime);
      if (file.type.startsWith('image/')) {
        setPiPreviewUrl(URL.createObjectURL(file));
      } else {
        setPiPreviewUrl(null);
      }

      // Auto generate immediately upon file upload if enabled
      if (autoGenerateOnUpload) {
        runExtraction(lcFileBase64, lcFileMimeType, lcFile?.name, base64, mime, file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const removeLcFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLcFile(null);
    setLcFileBase64('');
    setLcFileMimeType('');
    setLcPreviewUrl(null);
    if (lcInputRef.current) lcInputRef.current.value = '';
  };

  const removePiFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPiFile(null);
    setPiFileBase64('');
    setPiFileMimeType('');
    setPiPreviewUrl(null);
    if (piInputRef.current) piInputRef.current.value = '';
  };

  const handleLoadSample = (sample: TradeDocumentData) => {
    setCurrentDraft(sample);
    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(sample));
    setLcFile(null);
    setLcFileBase64('');
    setPiFile(null);
    setPiFileBase64('');
    setTextContent('');
    setStatusNotification({
      type: 'success',
      msg: 'Demo trade sample loaded! All 6 documents are ready to view or download.',
    });
  };

  const handleNewBlankDraft = () => {
    const today = new Date().toLocaleDateString('en-GB');
    const blankDoc: TradeDocumentData = {
      id: `draft-${Date.now()}`,
      documentType: 'LC',
      invoiceNo: '',
      invoiceDate: today,
      challanNo: '',
      challanDate: today,
      lcNo: '',
      lcDate: today,
      exportScLcNo: '',
      exportScLcDate: today,
      piNo: '',
      piDate: today,
      exporter: {
        name: 'SEVEN CLASSIC INDUSTRIES LTD.',
        factory: '1,NO SADHU MADBOR ROAD,MAMUDPUR,BHUIGHAR,FATULLAH,NARAYONGONJ.',
        headOffice:
          'ALAM TOWER (1ST FLOOR ) 12, D.I.T.AVENUE EXT.(EAST) MOTIJHEEL C/A,DHAKA-1000,BANGLADESH',
        beneficiaryBin: '000972873-0204',
        bankVatRegNo: '000000248-0002',
        ircNo: 'BA-159031',
        cell: '+880 1815 258978, 0191 1483 103',
        email: 'sevenclassic2021@gmail.com',
      },
      buyer: {
        name: '',
        address: '',
        plotNo: '',
        post: '',
        ps: '',
        district: '',
        country: 'BANGLADESH',
      },
      notifyParty: {
        name: '',
        address: '',
      },
      applicantBank: {
        bankName: '',
        branch: '',
        address: '',
      },
      exporterBankAccount: {
        bankName: 'SOUTHEAST BANK LIMITED',
        branch: 'UTTARA BRANCH',
        address:
          "''ARHAMS'' PLOT NO-79, SECTOR NO-07, DHAKA-MYMENSINGH,HIGHWAY, AZAMPUR, UTTARA, DHAKA-1230, BANGLADESH.",
      },
      negotiatingBank: {
        name: 'SOUTHEAST BANK PLC.',
        branch: 'MOUCHAK BRANCH',
        city: 'DHAKA,BANGLADESH.',
      },
      truckReceiptNo: '',
      truckReceiptDate: today,
      portOfLoading: "BENEFICIARY'S FACTORY",
      finalDestination: "OPENER'S FACTORY SITE",
      carrier: 'BY TRUCK',
      terms: "CFR OPENER'S FACTORY SITE",
      sailingAbout: '',
      itemsCategory: 'GARMENTS ACCESSORIES',
      items: [
        {
          itemNo: 1,
          particulars: '',
          eachPkg: '',
          quantity: 0,
          unit: 'Pcs',
          unitPrice: 0,
          totalAmount: 0,
        },
      ],
      totalQuantity: 0,
      totalQuantityUnit: 'Pcs',
      totalPkgCount: '',
      totalAmount: 0,
      amountInWords: 'SAY US DOLLARS ZERO ONLY',
      generatedAt: today,
    };
    setCurrentDraft(blankDoc);
    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(blankDoc));
    setLcFile(null);
    setLcFileBase64('');
    setPiFile(null);
    setPiFileBase64('');
    setTextContent('');
    setStatusNotification({
      type: 'success',
      msg: 'New blank trade document created.',
    });
  };

  const handleQuickDownloadPdf = (templateType: DocTemplateType) => {
    try {
      const doc = generateTradePdf(currentDraft, templateType);
      const safeInv = currentDraft.invoiceNo
        ? currentDraft.invoiceNo.replace(/[^a-zA-Z0-9]/g, '_')
        : 'Doc';
      doc.save(`SEVEN_CLASSIC_${templateType}_${safeInv}.pdf`);
    } catch (err) {
      console.error('Download error:', err);
      alert('Error generating PDF document.');
    }
  };

  const handleDownloadFull6PageSetPdf = () => {
    try {
      const doc = generateFull6PageTradeSetPdf(currentDraft);
      const safeInv = currentDraft.invoiceNo
        ? currentDraft.invoiceNo.replace(/[^a-zA-Z0-9]/g, '_')
        : 'Set';
      doc.save(`SEVEN_CLASSIC_ALL_6_PAGES_TRADE_SET_${safeInv}.pdf`);
    } catch (err) {
      console.error('Combined PDF error:', err);
      alert('Error generating 6-page complete PDF set.');
    }
  };

  const handleDownloadAllPdfs = () => {
    const templates: DocTemplateType[] = [
      'COMMERCIAL_INVOICE',
      'PACKING_LIST',
      'DELIVERY_CHALLAN',
      'BILL_OF_EXCHANGE',
      'CERTIFICATE_OF_ORIGIN',
      'BENEFICIARY_CERT',
    ];
    templates.forEach((tmpl, i) => {
      setTimeout(() => {
        handleQuickDownloadPdf(tmpl);
      }, i * 400);
    });
  };

  const handleItemChange = (index: number, field: keyof TradeItem, value: any) => {
    const updatedItems = [...currentDraft.items];
    const target = { ...updatedItems[index], [field]: value };
    if (field === 'quantity' || field === 'unitPrice') {
      const q = field === 'quantity' ? Number(value) || 0 : target.quantity;
      const p = field === 'unitPrice' ? Number(value) || 0 : target.unitPrice;
      target.totalAmount = Number((q * p).toFixed(2));
    }
    updatedItems[index] = target;

    const newTotal = updatedItems.reduce((acc, it) => acc + (it.totalAmount || 0), 0);
    const newQty = updatedItems.reduce((acc, it) => acc + (it.quantity || 0), 0);

    const updatedDoc: TradeDocumentData = {
      ...currentDraft,
      items: updatedItems,
      totalAmount: Number(newTotal.toFixed(2)),
      totalQuantity: newQty,
      amountInWords: numberToWordsUSD(newTotal),
    };
    setCurrentDraft(updatedDoc);
    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updatedDoc));
  };

  const handleAddItem = () => {
    const newItem: TradeItem = {
      itemNo: currentDraft.items.length + 1,
      particulars: '',
      eachPkg: '',
      quantity: 0,
      unit: 'Pcs',
      unitPrice: 0,
      totalAmount: 0,
    };
    const updatedItems = [...currentDraft.items, newItem];
    const newTotal = updatedItems.reduce((acc, it) => acc + it.totalAmount, 0);
    const newQty = updatedItems.reduce((acc, it) => acc + it.quantity, 0);
    const updatedDoc = {
      ...currentDraft,
      items: updatedItems,
      totalAmount: Number(newTotal.toFixed(2)),
      totalQuantity: newQty,
      amountInWords: numberToWordsUSD(newTotal),
    };
    setCurrentDraft(updatedDoc);
    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updatedDoc));
  };

  const handleRemoveItem = (index: number) => {
    if (currentDraft.items.length <= 1) return;
    const updatedItems = currentDraft.items.filter((_, idx) => idx !== index);
    const newTotal = updatedItems.reduce((acc, it) => acc + it.totalAmount, 0);
    const newQty = updatedItems.reduce((acc, it) => acc + it.quantity, 0);
    const updatedDoc = {
      ...currentDraft,
      items: updatedItems,
      totalAmount: Number(newTotal.toFixed(2)),
      totalQuantity: newQty,
      amountInWords: numberToWordsUSD(newTotal),
    };
    setCurrentDraft(updatedDoc);
    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updatedDoc));
  };

  const handleSyncToTracker = () => {
    if (!onDeductMaterialStock) return;
    let count = 0;
    currentDraft.items.forEach((item) => {
      const match = materials.find(
        (m) =>
          m.name.toLowerCase().includes('duplex') ||
          m.name.toLowerCase().includes('kraft') ||
          m.name.toLowerCase().includes('board')
      );
      if (match) {
        onDeductMaterialStock(match.id, Math.min(item.quantity, 500));
        count++;
      }
    });
    if (count > 0) {
      setSyncSuccessMsg(`Synchronized material balance with Raw Material Tracker!`);
      setTimeout(() => setSyncSuccessMsg(null), 4000);
    }
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-sky-950/90 via-slate-900 to-slate-900 p-5 rounded-xl border border-sky-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-400 text-xs font-bold border border-sky-500/30 uppercase tracking-wide flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-sky-400" /> SEVEN CLASSIC INDUSTRIES LTD.
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[11px] font-semibold border border-emerald-500/30 flex items-center gap-1">
              <Zap className="w-3 h-3" /> Auto Document Generator
            </span>
          </div>
          <h2 className="text-lg md:text-xl font-bold text-white">
            Letter of Credit (LC) & Proforma Invoice (PI) Trade Set Generator
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl mt-1">
            Upload your Letter of Credit (LC) and Proforma Invoice (PI) (PDF or image). The system
            automatically extracts Buyer, Issuing Bank, LC/PI numbers, and accessories line items, then
            drafts all 6 professional A4 print-ready documents instantly.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleNewBlankDraft}
            className="px-3.5 py-2 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow transition flex items-center gap-1.5"
            title="Start fresh blank draft"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Blank Draft</span>
          </button>
          <button
            onClick={() => handleLoadSample(SAMPLE_SEVEN_CLASSIC_DOC)}
            className="px-3 py-2 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Load Demo Preset</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Upload & PDF Hub */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 rounded-xl border border-slate-800 p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-sky-400" /> Document Upload
              </span>
              {/* Auto-generate toggle */}
              <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 select-none">
                <input
                  type="checkbox"
                  checked={autoGenerateOnUpload}
                  onChange={(e) => setAutoGenerateOnUpload(e.target.checked)}
                  className="rounded accent-sky-500 w-3.5 h-3.5"
                />
                <span className="text-sky-300 font-semibold">Auto-generate on upload</span>
              </label>
            </div>

            <div className="flex rounded-lg bg-slate-950 p-1 mb-4 border border-slate-800">
              <button
                onClick={() => setActiveTab('upload')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition ${
                  activeTab === 'upload'
                    ? 'bg-sky-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Upload LC / PI (PDF & Images)
              </button>
              <button
                onClick={() => setActiveTab('text')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition ${
                  activeTab === 'text'
                    ? 'bg-sky-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Paste LC / SWIFT Text
              </button>
              <button
                onClick={() => setActiveTab('samples')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition ${
                  activeTab === 'samples'
                    ? 'bg-sky-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sample Presets
              </button>
            </div>

            {/* TAB 1: Dual File Upload (LC & PI) */}
            {activeTab === 'upload' && (
              <div className="space-y-3">
                {/* Hidden File Inputs */}
                <input
                  type="file"
                  ref={lcInputRef}
                  onChange={handleLcChange}
                  accept="image/*,application/pdf,.txt"
                  className="hidden"
                />
                <input
                  type="file"
                  ref={piInputRef}
                  onChange={handlePiChange}
                  accept="image/*,application/pdf,.txt"
                  className="hidden"
                />

                {/* Dual Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Slot 1: LC (Letter of Credit) */}
                  <div
                    onClick={() => lcInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition relative group ${
                      lcFile
                        ? 'border-emerald-500/80 bg-emerald-950/20'
                        : 'border-slate-700 hover:border-sky-500/80 bg-slate-950/50 hover:bg-slate-950/80'
                    }`}
                  >
                    {lcPreviewUrl ? (
                      <div className="w-16 h-16 mx-auto mb-2 rounded border border-slate-700 overflow-hidden bg-black/40">
                        <img
                          src={lcPreviewUrl}
                          alt="LC Thumbnail"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2 transition ${
                          lcFile
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-sky-500/10 text-sky-400 group-hover:scale-105'
                        }`}
                      >
                        {lcFile ? <FileCheck className="w-5 h-5" /> : <Upload className="w-5 h-5" />}
                      </div>
                    )}
                    <div className="text-xs font-bold text-white mb-0.5">
                      {lcFile ? 'LC File Selected' : '1. Upload Letter of Credit (LC)'}
                    </div>
                    <p className="text-[10.5px] text-slate-400 line-clamp-1">
                      {lcFile ? lcFile.name : 'Master LC / Back-to-Back LC (PDF/JPG)'}
                    </p>
                    {lcFile ? (
                      <div className="mt-2 flex items-center justify-center gap-2">
                        <span className="text-[10px] text-emerald-300 font-mono">
                          {(lcFile.size / 1024).toFixed(1)} KB
                        </span>
                        <button
                          type="button"
                          onClick={removeLcFile}
                          className="text-[10px] px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-900 border border-rose-800"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <div className="mt-1 text-[10px] text-sky-400 font-medium">
                        Click or Drop file here
                      </div>
                    )}
                  </div>

                  {/* Slot 2: PI (Proforma Invoice) */}
                  <div
                    onClick={() => piInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition relative group ${
                      piFile
                        ? 'border-emerald-500/80 bg-emerald-950/20'
                        : 'border-slate-700 hover:border-sky-500/80 bg-slate-950/50 hover:bg-slate-950/80'
                    }`}
                  >
                    {piPreviewUrl ? (
                      <div className="w-16 h-16 mx-auto mb-2 rounded border border-slate-700 overflow-hidden bg-black/40">
                        <img
                          src={piPreviewUrl}
                          alt="PI Thumbnail"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2 transition ${
                          piFile
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-sky-500/10 text-sky-400 group-hover:scale-105'
                        }`}
                      >
                        {piFile ? <FileCheck className="w-5 h-5" /> : <Upload className="w-5 h-5" />}
                      </div>
                    )}
                    <div className="text-xs font-bold text-white mb-0.5">
                      {piFile ? 'PI File Selected' : '2. Upload Proforma Invoice (PI)'}
                    </div>
                    <p className="text-[10.5px] text-slate-400 line-clamp-1">
                      {piFile ? piFile.name : 'Proforma Invoice / Sales Contract (PDF/JPG)'}
                    </p>
                    {piFile ? (
                      <div className="mt-2 flex items-center justify-center gap-2">
                        <span className="text-[10px] text-emerald-300 font-mono">
                          {(piFile.size / 1024).toFixed(1)} KB
                        </span>
                        <button
                          type="button"
                          onClick={removePiFile}
                          className="text-[10px] px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-900 border border-rose-800"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <div className="mt-1 text-[10px] text-sky-400 font-medium">
                        Click or Drop file here
                      </div>
                    )}
                  </div>
                </div>

                {/* Helpful status strip */}
                <div className="p-2.5 rounded-lg bg-sky-950/40 border border-sky-800/40 text-[11px] text-slate-300 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-sky-300">Tip:</span> Upload either{' '}
                    <span className="text-white font-bold">LC</span>,{' '}
                    <span className="text-white font-bold">PI</span> or{' '}
                    <span className="text-white font-bold">Both</span> together for seamless drafting.
                  </div>
                  {autoGenerateOnUpload && (
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                      <Zap className="w-3 h-3 text-emerald-400" /> Auto-Run Active
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: Text Paste */}
            {activeTab === 'text' && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300">
                  Paste SWIFT MT700 or LC/PI text:
                </label>
                <textarea
                  value={textContent}
                  onChange={(e) => setTextContent(e.target.value)}
                  rows={7}
                  placeholder={`L/C NO. 1345260300051 Date.25/08/2026\nAPPLICANT: SINHA KNIT AND DENIMS LIMITED.\nEXPORT SC/LC NO. SKDL-TRENT-075-2026\nTwill Tape Wide: 2.00 Inch 481 gsm - 1388 Gyds @ $5.1932\nNon Elastic Tape Width:1.50 Inch - 1375 Gyds @ $5.1932`}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-200 focus:border-sky-500 outline-none"
                />
              </div>
            )}

            {/* TAB 3: Samples */}
            {activeTab === 'samples' && (
              <div className="space-y-2">
                <p className="text-xs text-slate-400 mb-2">
                  Select sample preset to test instant drafting:
                </p>
                <button
                  type="button"
                  onClick={() => handleLoadSample(SAMPLE_SEVEN_CLASSIC_DOC)}
                  className="w-full text-left p-3 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-sky-500/50 transition flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-bold text-white">
                      Sinha Knit and Denims Ltd. (Invoice 145/2026)
                    </div>
                    <div className="text-[11px] text-slate-400">
                      LC: 1345260300051 | Garments Accessories | $19,805.39
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-sky-400" />
                </button>
              </div>
            )}

            {/* Notification alert */}
            {statusNotification && (
              <div
                className={`mt-3 p-3 rounded-lg text-xs flex items-center gap-2 ${
                  statusNotification.type === 'success'
                    ? 'bg-emerald-950/70 border border-emerald-800 text-emerald-200'
                    : statusNotification.type === 'warning'
                    ? 'bg-amber-950/70 border border-amber-800 text-amber-200'
                    : 'bg-rose-950/70 border border-rose-800 text-rose-200'
                }`}
              >
                {statusNotification.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                )}
                <span>{statusNotification.msg}</span>
              </div>
            )}

            {/* Extraction Action Button */}
            <button
              onClick={() => runExtraction()}
              disabled={isProcessing}
              className="mt-4 w-full py-3 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-sky-900/30 transition disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>{progressStep || 'Extracting & Generating 6 Documents...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-sky-200" />
                  <span>
                    {lcFile && piFile
                      ? 'Generate All 6 Documents (LC & PI Uploaded)'
                      : lcFile
                      ? 'Generate All 6 Documents from LC'
                      : piFile
                      ? 'Generate All 6 Documents from PI'
                      : 'Generate 6 Trade Documents (CI, PL, DC, BE, CO, BC)'}
                  </span>
                </>
              )}
            </button>
          </div>

          {/* Instant PDF Generation & Download Hub */}
          <div className="bg-slate-900/90 rounded-xl border border-slate-800 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-sky-400" /> Print & PDF Export Hub
              </h3>
              <button
                onClick={handleDownloadAllPdfs}
                className="text-[10px] text-sky-400 hover:underline font-bold flex items-center gap-1"
              >
                <Download className="w-3 h-3" /> Download 6 PDFs
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onPreviewDoc(currentDraft, 'COMMERCIAL_INVOICE')}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">
                    Commercial Invoice (CI)
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Inv: {currentDraft.invoiceNo || 'N/A'}
                  </div>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-400" />
              </button>

              <button
                onClick={() => onPreviewDoc(currentDraft, 'PACKING_LIST')}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">
                    Packing List (PL)
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {currentDraft.totalPkgCount || 'Packages'}
                  </div>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-400" />
              </button>

              <button
                onClick={() => onPreviewDoc(currentDraft, 'DELIVERY_CHALLAN')}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">
                    Delivery / Truck Chalan
                  </div>
                  <div className="text-[10px] text-slate-500">Truck Delivery</div>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-400" />
              </button>

              <button
                onClick={() => onPreviewDoc(currentDraft, 'BILL_OF_EXCHANGE')}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">
                    Bill of Exchange (1 & 2)
                  </div>
                  <div className="text-[10px] text-slate-500">First & Second on Sheet</div>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-400" />
              </button>

              <button
                onClick={() => onPreviewDoc(currentDraft, 'CERTIFICATE_OF_ORIGIN')}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">
                    Certificate of Origin
                  </div>
                  <div className="text-[10px] text-slate-500">1 to 13 Clauses</div>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-400" />
              </button>

              <button
                onClick={() => onPreviewDoc(currentDraft, 'BENEFICIARY_CERT')}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-left transition group"
              >
                <div>
                  <div className="text-xs font-bold text-slate-200 group-hover:text-sky-400">
                    Beneficiary's Cert
                  </div>
                  <div className="text-[10px] text-slate-500">Official Declaration</div>
                </div>
                <Eye className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-400" />
              </button>
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-2.5">
              <button
                onClick={handleDownloadFull6PageSetPdf}
                className="w-full py-2.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md transition flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" /> Download All 6 Pages (1 Combined PDF)
              </button>

              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-400">
                  Separate Single PDFs:
                </span>
                <button
                  onClick={handleDownloadAllPdfs}
                  className="text-[10px] text-sky-400 hover:underline font-bold"
                >
                  Download All 6 Files
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1.5">
                <button
                  onClick={() => handleQuickDownloadPdf('COMMERCIAL_INVOICE')}
                  className="py-1.5 px-2 rounded bg-slate-800 hover:bg-sky-600 text-[10.5px] font-semibold text-slate-200 hover:text-white transition flex items-center justify-center gap-1"
                >
                  <Download className="w-3 h-3" /> Invoice PDF
                </button>
                <button
                  onClick={() => handleQuickDownloadPdf('PACKING_LIST')}
                  className="py-1.5 px-2 rounded bg-slate-800 hover:bg-sky-600 text-[10.5px] font-semibold text-slate-200 hover:text-white transition flex items-center justify-center gap-1"
                >
                  <Download className="w-3 h-3" /> Packing PDF
                </button>
                <button
                  onClick={() => handleQuickDownloadPdf('DELIVERY_CHALLAN')}
                  className="py-1.5 px-2 rounded bg-slate-800 hover:bg-sky-600 text-[10.5px] font-semibold text-slate-200 hover:text-white transition flex items-center justify-center gap-1"
                >
                  <Download className="w-3 h-3" /> Chalan PDF
                </button>
                <button
                  onClick={() => handleQuickDownloadPdf('BILL_OF_EXCHANGE')}
                  className="py-1.5 px-2 rounded bg-slate-800 hover:bg-sky-600 text-[10.5px] font-semibold text-slate-200 hover:text-white transition flex items-center justify-center gap-1"
                >
                  <Download className="w-3 h-3" /> Bill PDF
                </button>
                <button
                  onClick={() => handleQuickDownloadPdf('CERTIFICATE_OF_ORIGIN')}
                  className="py-1.5 px-2 rounded bg-slate-800 hover:bg-sky-600 text-[10.5px] font-semibold text-slate-200 hover:text-white transition flex items-center justify-center gap-1"
                >
                  <Download className="w-3 h-3" /> Origin PDF
                </button>
                <button
                  onClick={() => handleQuickDownloadPdf('BENEFICIARY_CERT')}
                  className="py-1.5 px-2 rounded bg-slate-800 hover:bg-sky-600 text-[10.5px] font-semibold text-slate-200 hover:text-white transition flex items-center justify-center gap-1"
                >
                  <Download className="w-3 h-3" /> Beneficiary PDF
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Draft Fields & Line Items Editor */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900/90 rounded-xl border border-slate-800 p-5 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <div className="text-xs font-bold text-sky-400 uppercase tracking-wide flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Active Trade Draft Details
                </div>
                <div className="text-sm font-black text-white mt-0.5">
                  {currentDraft.buyer?.name || 'Buyer Name'}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onPreviewDoc(currentDraft, 'COMMERCIAL_INVOICE')}
                  className="px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1.5 shadow transition"
                >
                  <Eye className="w-3.5 h-3.5" /> View A4 Paper Preview
                </button>
              </div>
            </div>

            {/* Sync banner */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-200">
                    Sync with Raw Material Tracker
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Deduct raw materials automatically based on accessories produced
                  </div>
                </div>
              </div>
              <button
                onClick={handleSyncToTracker}
                className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 shrink-0"
              >
                <Package className="w-3.5 h-3.5" /> Sync Stock
              </button>
            </div>

            {syncSuccessMsg && (
              <div className="p-2.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{syncSuccessMsg}</span>
              </div>
            )}

            {/* Fields Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 sm:col-span-2">
                <label className="text-[10px] text-sky-400 font-semibold block uppercase">
                  Buyer / Applicant Name (From LC)
                </label>
                <input
                  type="text"
                  value={currentDraft.buyer?.name || ''}
                  onChange={(e) => {
                    const newName = e.target.value;
                    const wasSyncWithNotify =
                      !currentDraft.notifyParty?.name ||
                      currentDraft.notifyParty?.name === currentDraft.buyer?.name;
                    const updated = {
                      ...currentDraft,
                      buyer: { ...currentDraft.buyer, name: newName },
                      notifyParty: wasSyncWithNotify
                        ? {
                            ...(currentDraft.notifyParty || { address: '' }),
                            name: newName,
                          }
                        : currentDraft.notifyParty,
                    };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  placeholder="e.g. SINHA KNIT AND DENIMS LIMITED"
                  className="w-full bg-transparent font-bold text-slate-100 outline-none text-xs mt-1"
                />
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  P/I Number & Date
                </label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="text"
                    value={currentDraft.piNo || ''}
                    onChange={(e) => {
                      const updated = { ...currentDraft, piNo: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    placeholder="P/I No"
                    className="w-full bg-transparent font-mono font-bold text-slate-200 outline-none text-xs"
                  />
                  <input
                    type="text"
                    value={currentDraft.piDate || ''}
                    onChange={(e) => {
                      const updated = { ...currentDraft, piDate: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    placeholder="DD/MM/YYYY"
                    className="w-24 bg-transparent font-mono text-slate-300 outline-none text-xs text-right"
                  />
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 sm:col-span-3">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Buyer / Applicant Address (From LC)
                </label>
                <input
                  type="text"
                  value={currentDraft.buyer?.address || ''}
                  onChange={(e) => {
                    const newAddr = e.target.value;
                    const wasSyncWithNotify =
                      !currentDraft.notifyParty?.address ||
                      currentDraft.notifyParty?.address === currentDraft.buyer?.address;
                    const updated = {
                      ...currentDraft,
                      buyer: { ...currentDraft.buyer, address: newAddr, plotNo: newAddr },
                      notifyParty: wasSyncWithNotify
                        ? {
                            ...(currentDraft.notifyParty || { name: '' }),
                            address: newAddr,
                          }
                        : currentDraft.notifyParty,
                    };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  placeholder="PLOT NO, POST, PS, DISTRICT, COUNTRY"
                  className="w-full bg-transparent text-slate-200 outline-none text-xs mt-1"
                />
              </div>

              {/* Notify Party (From LC) */}
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 sm:col-span-2">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-indigo-400 font-semibold block uppercase">
                    Notify Party Name (From LC)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = {
                        ...currentDraft,
                        notifyParty: {
                          name: currentDraft.buyer?.name || '',
                          address: currentDraft.buyer?.address || '',
                        },
                      };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="text-[10px] text-sky-400 hover:text-sky-300 underline"
                  >
                    Same as Applicant
                  </button>
                </div>
                <input
                  type="text"
                  value={currentDraft.notifyParty?.name || ''}
                  onChange={(e) => {
                    const updated = {
                      ...currentDraft,
                      notifyParty: {
                        ...(currentDraft.notifyParty || { address: '' }),
                        name: e.target.value,
                      },
                    };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  placeholder="Same as Applicant or distinct Notify Party"
                  className="w-full bg-transparent font-bold text-slate-100 outline-none text-xs mt-1"
                />
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Notify Party Address
                </label>
                <input
                  type="text"
                  value={currentDraft.notifyParty?.address || ''}
                  onChange={(e) => {
                    const updated = {
                      ...currentDraft,
                      notifyParty: {
                        ...(currentDraft.notifyParty || { name: '' }),
                        address: e.target.value,
                      },
                    };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  placeholder="Notify Party Address"
                  className="w-full bg-transparent text-slate-200 outline-none text-xs mt-1"
                />
              </div>

              {/* Applicant Bank / Consignee Bank (A/C Bank from LC) */}
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 sm:col-span-2">
                <label className="text-[10px] text-amber-400 font-semibold block uppercase">
                  Applicant Bank / LC Issuing Bank Name & Branch
                </label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="text"
                    value={currentDraft.applicantBank?.bankName || ''}
                    onChange={(e) => {
                      const updated = {
                        ...currentDraft,
                        applicantBank: {
                          ...(currentDraft.applicantBank || { branch: '', address: '' }),
                          bankName: e.target.value,
                        },
                      };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    placeholder="e.g. SOUTHEAST BANK LIMITED or DUTCH BANGLA BANK"
                    className="w-full bg-transparent font-bold text-slate-100 outline-none text-xs"
                  />
                  <input
                    type="text"
                    value={currentDraft.applicantBank?.branch || ''}
                    onChange={(e) => {
                      const updated = {
                        ...currentDraft,
                        applicantBank: {
                          ...(currentDraft.applicantBank || { bankName: '', address: '' }),
                          branch: e.target.value,
                        },
                      };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    placeholder="Branch (e.g. UTTARA BRANCH)"
                    className="w-40 bg-transparent font-mono text-slate-300 outline-none text-xs text-right"
                  />
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 sm:col-span-1">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Applicant Bank Address
                </label>
                <input
                  type="text"
                  value={currentDraft.applicantBank?.address || ''}
                  onChange={(e) => {
                    const updated = {
                      ...currentDraft,
                      applicantBank: {
                        ...(currentDraft.applicantBank || { bankName: '', branch: '' }),
                        address: e.target.value,
                      },
                    };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  placeholder="PLOT NO, SECTOR, CITY"
                  className="w-full bg-transparent text-slate-300 outline-none text-xs mt-1"
                />
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  L/C Number & Date
                </label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="text"
                    value={currentDraft.lcNo}
                    onChange={(e) => {
                      const updated = { ...currentDraft, lcNo: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="w-full bg-transparent font-mono font-bold text-slate-200 outline-none text-xs"
                  />
                  <input
                    type="text"
                    value={currentDraft.lcDate}
                    onChange={(e) => {
                      const updated = { ...currentDraft, lcDate: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="w-24 bg-transparent font-mono text-slate-300 outline-none text-xs text-right"
                  />
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Export SC/LC No & Date
                </label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="text"
                    value={currentDraft.exportScLcNo}
                    onChange={(e) => {
                      const updated = { ...currentDraft, exportScLcNo: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="w-full bg-transparent font-mono text-slate-200 outline-none text-xs"
                  />
                  <input
                    type="text"
                    value={currentDraft.exportScLcDate}
                    onChange={(e) => {
                      const updated = { ...currentDraft, exportScLcDate: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="w-24 bg-transparent font-mono text-slate-300 outline-none text-xs text-right"
                  />
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Invoice No & Date
                </label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="text"
                    value={currentDraft.invoiceNo}
                    onChange={(e) => {
                      const updated = { ...currentDraft, invoiceNo: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="w-full bg-transparent font-mono font-bold text-slate-200 outline-none text-xs"
                  />
                  <input
                    type="text"
                    value={currentDraft.invoiceDate}
                    onChange={(e) => {
                      const updated = { ...currentDraft, invoiceDate: e.target.value };
                      setCurrentDraft(updated);
                      localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                    }}
                    className="w-24 bg-transparent font-mono text-slate-300 outline-none text-xs text-right"
                  />
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Delivery Challan No
                </label>
                <input
                  type="text"
                  value={currentDraft.challanNo}
                  onChange={(e) => {
                    const updated = { ...currentDraft, challanNo: e.target.value };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  className="w-full bg-transparent font-mono font-bold text-slate-200 outline-none text-xs mt-1"
                />
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Truck Receipt (T/R No)
                </label>
                <input
                  type="text"
                  value={currentDraft.truckReceiptNo}
                  onChange={(e) => {
                    const updated = { ...currentDraft, truckReceiptNo: e.target.value };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  className="w-full bg-transparent font-mono text-slate-200 outline-none text-xs mt-1"
                />
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <label className="text-[10px] text-slate-500 font-semibold block uppercase">
                  Total Packaging (Pkg)
                </label>
                <input
                  type="text"
                  value={currentDraft.totalPkgCount || '30000 Pkg'}
                  onChange={(e) => {
                    const updated = { ...currentDraft, totalPkgCount: e.target.value };
                    setCurrentDraft(updated);
                    localStorage.setItem('sevenClassicCurrentDraft', JSON.stringify(updated));
                  }}
                  className="w-full bg-transparent font-mono font-bold text-slate-200 outline-none text-xs mt-1"
                />
              </div>
            </div>

            {/* Line items table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Goods Particulars & Accessories Line Items ({currentDraft.items.length})
                </h4>
                <button
                  onClick={handleAddItem}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 transition"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Line Item
                </button>
              </div>

              <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                {currentDraft.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 text-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <input
                          type="text"
                          value={item.particulars}
                          onChange={(e) => handleItemChange(idx, 'particulars', e.target.value)}
                          className="w-full bg-transparent font-semibold text-slate-100 outline-none border-b border-transparent focus:border-sky-500 py-0.5"
                          placeholder="Particulars (e.g. Twill Tape Wide: 2.00 Inch 481 gsm)"
                        />
                      </div>
                      {currentDraft.items.length > 1 && (
                        <button
                          onClick={() => handleRemoveItem(idx)}
                          className="text-slate-500 hover:text-rose-400 p-1 transition"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block">Packaging (EACH)</span>
                        <input
                          type="text"
                          value={item.eachPkg || '3000 Pkg'}
                          onChange={(e) => handleItemChange(idx, 'eachPkg', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs font-mono text-slate-300 outline-none"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">
                          Quantity ({item.unit})
                        </span>
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs font-mono font-bold text-slate-200 outline-none"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">Unit Price ($)</span>
                        <input
                          type="number"
                          step="0.0001"
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(idx, 'unitPrice', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs font-mono text-slate-200 outline-none"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">Total Amount</span>
                        <div className="px-2 py-1 rounded bg-slate-900 border border-slate-800 font-mono font-bold text-emerald-400 text-xs">
                          $
                          {item.totalAmount.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Total Banner */}
              <div className="p-3.5 rounded-lg bg-sky-950/40 border border-sky-500/30 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="text-[10px] uppercase font-bold text-sky-400">
                    Total Invoiced Amount (USD)
                  </div>
                  <div className="text-xl font-black text-white font-mono">
                    $
                    {currentDraft.totalAmount.toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}{' '}
                    USD
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-slate-400">
                    Total Quantity
                  </div>
                  <div className="text-sm font-bold text-slate-200 font-mono">
                    {currentDraft.totalQuantity.toLocaleString()} {currentDraft.totalQuantityUnit}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
