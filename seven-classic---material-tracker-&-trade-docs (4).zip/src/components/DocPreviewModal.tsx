import React, { useState } from 'react';
import { DocTemplateType, TradeDocumentData } from '../types';
import { generateTradePdf, generateFull6PageTradeSetPdf } from '../utils/pdfGenerator';
import {
  Download,
  Printer,
  Copy,
  Check,
  X,
  FileText,
  Package,
  Truck,
  Landmark,
  ShieldCheck,
  Award,
} from 'lucide-react';

interface DocPreviewModalProps {
  data: TradeDocumentData;
  initialType?: DocTemplateType;
  onClose: () => void;
}

export const DocPreviewModal: React.FC<DocPreviewModalProps> = ({
  data,
  initialType = 'COMMERCIAL_INVOICE',
  onClose,
}) => {
  const [activeType, setActiveType] = useState<DocTemplateType>(initialType);
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const docTabs: { type: DocTemplateType; label: string; icon: any; short: string }[] = [
    { type: 'COMMERCIAL_INVOICE', label: 'Commercial Invoice (CI)', icon: FileText, short: 'Invoice' },
    { type: 'PACKING_LIST', label: 'Packing List (PL)', icon: Package, short: 'Packing' },
    {
      type: 'DELIVERY_CHALLAN',
      label: 'Delivery Chalan / Truck Chalan',
      icon: Truck,
      short: 'Challan',
    },
    {
      type: 'BILL_OF_EXCHANGE',
      label: 'Bill of Exchange (1 & 2)',
      icon: Landmark,
      short: 'Bank Draft',
    },
    {
      type: 'CERTIFICATE_OF_ORIGIN',
      label: 'Certificate of Origin',
      icon: Award,
      short: 'Origin',
    },
    {
      type: 'BENEFICIARY_CERT',
      label: "Beneficiary's Certificate",
      icon: ShieldCheck,
      short: 'Certificate',
    },
  ];

  const handleDownloadPdf = () => {
    try {
      setIsDownloading(true);
      const doc = generateTradePdf(data, activeType);
      const fileName = `SEVEN_CLASSIC_${activeType}_${
        data.invoiceNo ? data.invoiceNo.replace(/[^a-zA-Z0-9]/g, '_') : 'Doc'
      }.pdf`;
      doc.save(fileName);
    } catch (err) {
      console.error('Failed to generate PDF:', err);
      alert('Could not generate PDF. Please try again or use the Print button.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadFullSetPdf = () => {
    try {
      setIsDownloading(true);
      const doc = generateFull6PageTradeSetPdf(data);
      const fileName = `SEVEN_CLASSIC_ALL_6_PAGES_TRADE_SET_${
        data.invoiceNo ? data.invoiceNo.replace(/[^a-zA-Z0-9]/g, '_') : 'Set'
      }.pdf`;
      doc.save(fileName);
    } catch (err) {
      console.error('Failed to generate full set PDF:', err);
      alert('Could not generate full set PDF.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyText = () => {
    const textLines = [
      '====================================================',
      'SEVEN CLASSIC INDUSTRIES LTD. - OFFICIAL TRADE DRAFT',
      `DOCUMENT: ${activeType.replace(/_/g, ' ')}`,
      '====================================================',
      `INVOICE NO: ${data.invoiceNo} | DATE: ${data.invoiceDate}`,
      `DELIVERY CHALLAN NO: ${data.challanNo} | DATE: ${data.challanDate}`,
      `L/C NO: ${data.lcNo} | DATE: ${data.lcDate}`,
      `EXPORT SC/LC NO: ${data.exportScLcNo} | DATE: ${data.exportScLcDate}`,
      `BUYER: ${data.buyer?.name || ''}`,
      `T/R NO: ${data.truckReceiptNo}`,
      `TOTAL AMOUNT: $${data.totalAmount.toLocaleString()} USD`,
      `IN WORDS: ${data.amountInWords}`,
      '====================================================',
    ];
    navigator.clipboard.writeText(textLines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const items = data.items || [];
  const buyerName = data.buyer?.name?.trim() || '';
  const notifyName = data.notifyParty?.name?.trim() || '';
  const applicantName = buyerName || notifyName || '';
  const notifyPartyName = notifyName || buyerName || '';

  const applicantAddress =
    data.buyer?.address?.trim() ||
    data.buyer?.plotNo?.trim() ||
    data.notifyParty?.address?.trim() ||
    '';

  const postPart = data.buyer?.post ? `POST : ${data.buyer.post}` : '';
  const psPart = data.buyer?.ps ? `PS: ${data.buyer.ps}` : '';
  const districtPart = data.buyer?.district || '';
  const countryPart = data.buyer?.country || 'BANGLADESH';

  const appBankName = data.applicantBank?.bankName?.trim() || '';
  const appBankBranch = data.applicantBank?.branch?.trim() || '';
  const appBankAddress = data.applicantBank?.address?.trim() || '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-5xl rounded-xl shadow-2xl flex flex-col max-h-[96vh] text-slate-100 overflow-hidden">
        {/* Top Header / Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400 font-bold text-sm">
              7C
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
                SEVEN CLASSIC INDUSTRIES LTD. — Trade Document Preview
              </h2>
              <p className="text-[11px] text-slate-400">
                A4 Print Ready format matching official customs and banking submission standards
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyText}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              title="Copy Draft Text"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Text'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              title="Print Document"
            >
              <Printer className="w-3.5 h-3.5 text-sky-400" />
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={isDownloading}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded bg-sky-600 hover:bg-sky-500 text-white shadow transition disabled:opacity-50"
              title="Download current preview page as PDF"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isDownloading ? 'Generating...' : 'Download Current'}</span>
            </button>

            <button
              onClick={handleDownloadFullSetPdf}
              disabled={isDownloading}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded bg-emerald-600 hover:bg-emerald-500 text-white shadow transition disabled:opacity-50"
              title="Download all 6 pages combined in 1 PDF file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isDownloading ? '...' : 'All 6 Pages (1 PDF)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Template Selector Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 border-b border-slate-800 overflow-x-auto no-scrollbar">
          {docTabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeType === tab.type;
            return (
              <button
                key={tab.type}
                onClick={() => setActiveType(tab.type)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                  active
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.short}</span>
              </button>
            );
          })}
        </div>

        {/* Paper Document Preview Area */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-slate-950 flex justify-center">
          <div
            id="printable-trade-document"
            className="w-full max-w-[820px] bg-white text-black p-6 sm:p-10 shadow-2xl rounded-sm font-sans text-xs select-text relative"
            style={{ minHeight: '1050px' }}
          >
            {/* ========================================================
                1. COMMERCIAL INVOICE PREVIEW
            ======================================================== */}
            {activeType === 'COMMERCIAL_INVOICE' && (
              <div className="border border-black flex flex-col">
                <div className="text-center py-2 border-b border-black">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                    SEVEN CLASSIC INDUSTRIES LTD.
                  </h1>
                  <h2 className="text-base sm:text-lg font-bold tracking-wide mt-0.5">
                    COMMERCIAL INVOICE
                  </h2>
                </div>

                {/* Grid Row 1: Shipper / Invoice No */}
                <div className="grid grid-cols-2 border-b border-black text-[11px]">
                  <div className="p-2 border-r border-black space-y-0.5">
                    <div className="font-bold">SHIPPER/ EXPORTER :-</div>
                    <div className="font-bold">{data.exporter.name}</div>
                    <div>1,NO SADHU MADBOR ROAD,MAMUDPUR,</div>
                    <div>BHUIGHAR,FATULLAH,NARAYONGONJ.</div>
                  </div>
                  <div className="text-[11px]">
                    <div className="flex justify-between p-2 border-b border-black">
                      <span className="font-bold">
                        Invoice No. <span className="font-normal ml-2">{data.invoiceNo}</span>
                      </span>
                      <span>Date.{data.invoiceDate}</span>
                    </div>
                    <div className="flex justify-between p-2">
                      <span className="font-bold">
                        L/C NO. <span className="font-normal ml-2">{data.lcNo}</span>
                      </span>
                      <span>Date.{data.lcDate}</span>
                    </div>
                  </div>
                </div>

                {/* Grid Row 2: Notify Party / LC Credentials */}
                <div className="grid grid-cols-2 border-b border-black text-[11px]">
                  <div className="p-2 border-r border-black space-y-0.5">
                    <div className="font-bold">NOTIFY PARTY/APPLICANT.:</div>
                    {notifyPartyName &&
                    applicantName &&
                    notifyPartyName.toLowerCase() !== applicantName.toLowerCase() ? (
                      <>
                        <div className="font-bold">NOTIFY: {notifyPartyName}</div>
                        <div className="font-bold">APPLICANT: {applicantName}</div>
                      </>
                    ) : (
                      <div className="font-bold">{applicantName}</div>
                    )}
                    <div>{applicantAddress}</div>
                    {(postPart || psPart) && (
                      <div>
                        {postPart}
                        {postPart && psPart ? ', ' : ''}
                        {psPart}, {districtPart}, {countryPart}.
                      </div>
                    )}
                    {appBankName && (
                      <div className="font-bold text-[10px] pt-1">
                        A/C NO:- {appBankName}
                        {appBankBranch ? `, ${appBankBranch}` : ''}{' '}
                        {appBankAddress && `, ${appBankAddress}`}
                      </div>
                    )}
                  </div>
                  <div className="divide-y divide-black text-[10.5px]">
                    <div className="p-1.5 font-bold">
                      EXPORT SC/LC NO. {data.exportScLcNo} Dt.{data.exportScLcDate}
                    </div>
                    <div className="p-1.5 font-bold">
                      BENEFICIARY BIN NO.{data.exporter.beneficiaryBin}
                    </div>
                    <div className="p-1.5 font-bold">
                      BANK VAT REG.NO. {data.exporter.bankVatRegNo}
                    </div>
                    <div className="p-1.5 font-bold">IRC NO.{data.exporter.ircNo}</div>
                    <div className="p-1.5 font-bold">
                      T/R NO.: {data.truckReceiptNo} Date.{data.truckReceiptDate}
                    </div>
                  </div>
                </div>

                {/* Grid Row 3: Ports */}
                <div className="grid grid-cols-2 border-b border-black text-[11px] p-1.5 font-bold">
                  <div>PORT OF LOADING : BENEFICIARY'S FACTORY</div>
                  <div>FINAL DESTINATION : OPENER'S FACTORY SITE</div>
                </div>

                {/* Grid Row 4: Carrier */}
                <div className="grid grid-cols-2 border-b border-black text-[11px] p-1.5 font-bold">
                  <div>CARRIER : BY TRUCK</div>
                  <div>SAILING ON OR ABOUT :</div>
                </div>

                {/* Grid Row 5: CFR */}
                <div className="border-b border-black text-[11px] p-1.5 font-bold">
                  CFR OPENER'S FACTORY SITE
                </div>

                {/* Table */}
                <table className="w-full border-collapse text-[10.5px]">
                  <thead>
                    <tr className="border-b border-black text-center font-bold">
                      <th className="p-1.5 border-r border-black w-12">S/L NO.</th>
                      <th className="p-1.5 border-r border-black text-left">PARTICULARS</th>
                      <th className="p-1.5 border-r border-black w-20">Ctn/No.</th>
                      <th className="p-1.5 border-r border-black w-28">Qty/Gyds/Dzn/Pcs.</th>
                      <th className="p-1.5 border-r border-black w-20">Unit Price</th>
                      <th className="p-1.5 w-24 text-right">Amount USD.</th>
                    </tr>
                    <tr className="border-b border-black">
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black text-left font-bold underline pl-2">
                        {data.itemsCategory || 'GARMENTS ACCESSORIES'}
                      </th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((it, idx) => (
                      <tr key={idx} className="border-b border-black/40">
                        <td className="p-1 border-r border-black text-center">{it.itemNo}</td>
                        <td className="p-1 border-r border-black font-medium">{it.particulars}</td>
                        <td className="p-1 border-r border-black text-center">
                          {it.ctnNo || (idx === 0 ? data.challanNo : '')}
                        </td>
                        <td className="p-1 border-r border-black text-right pr-2 font-mono">
                          {it.quantity.toLocaleString()} {it.unit}
                        </td>
                        <td className="p-1 border-r border-black text-right pr-2 font-mono">
                          ${it.unitPrice.toFixed(4)}
                        </td>
                        <td className="p-1 text-right pr-2 font-mono font-bold">
                          $
                          {it.totalAmount.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Total Row */}
                <div className="grid grid-cols-[1fr_auto_auto] border-t border-b border-black p-1.5 font-bold text-[11px]">
                  <div>TOTAL :</div>
                  <div className="pr-12">
                    {data.totalQuantity.toLocaleString()} {data.totalQuantityUnit}
                  </div>
                  <div className="pr-2">
                    $
                    {data.totalAmount.toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </div>
                </div>

                {/* Amount in words */}
                <div className="p-2 border-b border-black font-bold text-[10.5px]">
                  {data.amountInWords}
                </div>

                {/* Certificate of origin */}
                <div className="p-1.5 border-b border-black text-[9.5px] text-center font-bold">
                  THIS IS TO CERTIFY THAT THE MERCHANDISE DELIVERED/SUPPLIED TO THE ABOVE MENTIONED BUYERS ARE OF BANGALDESH ORIGIN.
                </div>

                {/* Sign-off */}
                <div className="p-6 pt-16 flex flex-col items-start text-[11px] font-bold">
                  <div>FOR,</div>
                  <div>SEVEN CLASSIC INDUSTRIES LTD.</div>
                  <div className="mt-12">AUTHORIZED SIGNATURE</div>
                </div>
              </div>
            )}

            {/* ========================================================
                2. PACKING LIST PREVIEW
            ======================================================== */}
            {activeType === 'PACKING_LIST' && (
              <div className="border border-black flex flex-col">
                <div className="text-center py-2 border-b border-black">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                    SEVEN CLASSIC INDUSTRIES LTD.
                  </h1>
                  <h2 className="text-base sm:text-lg font-bold tracking-wide mt-0.5">
                    PACKING LIST
                  </h2>
                </div>

                {/* Shipper & Delivery Challan */}
                <div className="grid grid-cols-2 border-b border-black text-[11px]">
                  <div className="p-2 border-r border-black space-y-0.5">
                    <div className="font-bold">SHIPPER/ EXPORTER</div>
                    <div className="font-bold">{data.exporter.name}</div>
                    <div>1,NO SADHU MADBOR ROAD,MAMUDPUR,</div>
                    <div>BHUIGHAR,FATULLAH,NARAYONGONJ.</div>
                  </div>
                  <div className="text-[11px]">
                    <div className="flex justify-between p-2 border-b border-black">
                      <span className="font-bold">
                        DELIVERY CHALLAN NO. <span className="font-normal ml-2">{data.challanNo}</span>
                      </span>
                      <span>Date.{data.challanDate}</span>
                    </div>
                    <div className="p-2">
                      <span className="font-bold">
                        L/C NO. {data.lcNo} Date.{data.lcDate}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Consignee & Details */}
                <div className="grid grid-cols-2 border-b border-black text-[11px]">
                  <div className="p-2 border-r border-black space-y-0.5">
                    <div className="font-bold">CONSIGNEE OR ORDER :</div>
                    <div className="font-bold">TO THE ORDER OF :</div>
                    <div className="font-bold">{applicantName}</div>
                    <div>{applicantAddress}</div>
                    {(postPart || psPart) && (
                      <div>
                        {postPart}
                        {postPart && psPart ? ', ' : ''}
                        {psPart}
                      </div>
                    )}
                    {appBankName && (
                      <div className="font-bold text-[10px] pt-1">
                        A/C NO:- {appBankName}
                        {appBankBranch ? `, ${appBankBranch}` : ''}{' '}
                        {appBankAddress && `, ${appBankAddress}`}
                      </div>
                    )}
                  </div>
                  <div className="divide-y divide-black text-[10.5px]">
                    <div className="p-1.5 font-bold">
                      EXPORT SC/LC NO. {data.exportScLcNo} Dt.{data.exportScLcDate}
                    </div>
                    <div className="p-1.5 font-bold">
                      BENEFICIARY BIN NO.{data.exporter.beneficiaryBin}
                    </div>
                    <div className="p-1.5 font-bold">
                      BANK VAT REG.NO. {data.exporter.bankVatRegNo}
                    </div>
                    <div className="p-1.5 font-bold">IRC NO.{data.exporter.ircNo}</div>
                    <div className="p-1.5 font-bold">
                      T/R NO.: {data.truckReceiptNo} Date.{data.truckReceiptDate}
                    </div>
                  </div>
                </div>

                {/* Ports & Marks */}
                <div className="grid grid-cols-2 border-b border-black text-[11px] p-1.5 font-bold">
                  <div>PORT OF LOADING : BENEFICIARY'S FACTORY</div>
                  <div>FINAL DESTINATION : OPENER'S FACTORY SITE</div>
                </div>
                <div className="border-b border-black text-[11px] p-1.5 font-bold">
                  MARKS & NUMBERS
                </div>

                {/* Table */}
                <table className="w-full border-collapse text-[10.5px]">
                  <thead>
                    <tr className="border-b border-black text-center font-bold">
                      <th className="p-1.5 border-r border-black w-12">SL.NO.</th>
                      <th className="p-1.5 border-r border-black text-left">PARTICULARS</th>
                      <th className="p-1.5 border-r border-black w-24">EACH</th>
                      <th className="p-1.5 border-r border-black w-28">QUANTITY</th>
                      <th className="p-1.5 w-32 text-right pr-2">
                        TOTAL QNTY (IN Yds./Mtr/Dzn/Pcs)
                      </th>
                    </tr>
                    <tr className="border-b border-black">
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black text-left font-bold underline pl-2">
                        {data.itemsCategory || 'GARMENTS ACCESSORIES'}
                      </th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((it, idx) => (
                      <tr key={idx} className="border-b border-black/40">
                        <td className="p-1 border-r border-black text-center">{it.itemNo}</td>
                        <td className="p-1 border-r border-black font-medium">{it.particulars}</td>
                        <td className="p-1 border-r border-black text-center">
                          {it.eachPkg || '3000 Pkg'}
                        </td>
                        <td className="p-1 border-r border-black text-right pr-2 font-mono">
                          {it.quantity.toLocaleString()} {it.unit}
                        </td>
                        <td className="p-1 text-right pr-2 font-mono font-bold">
                          {it.quantity.toLocaleString()} {it.unit}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Total */}
                <div className="grid grid-cols-[1fr_auto_auto] border-t border-b border-black p-1.5 font-bold text-[11px]">
                  <div></div>
                  <div className="pr-12">{data.totalPkgCount || '30000 Pkg'}</div>
                  <div className="pr-2">
                    {data.totalQuantity.toLocaleString()} {data.totalQuantityUnit}
                  </div>
                </div>

                {/* Sign-off */}
                <div className="p-6 pt-12 flex flex-col items-end text-[11px] font-bold">
                  <div className="w-56 text-left">
                    <div>FOR</div>
                    <div>SEVEN CLASSIC INDUSTRIES LTD.</div>
                    <div className="mt-12">AUTHORIZED SIGNATURE</div>
                  </div>
                </div>

                {/* 3-Line Footer */}
                <div className="border-t border-black p-2 text-[8.5px] font-bold space-y-0.5">
                  <div>HEAD OFFICE : {data.exporter.headOffice}</div>
                  <div>FACTORY : {data.exporter.factory}</div>
                  <div>
                    CELL : {data.exporter.cell}. Email : {data.exporter.email}
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================
                3. DELIVERY CHALAN / TRUCK CHALAN PREVIEW
            ======================================================== */}
            {activeType === 'DELIVERY_CHALLAN' && (
              <div className="border border-black flex flex-col">
                <div className="text-center py-2 border-b border-black">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                    SEVEN CLASSIC INDUSTRIES LTD.
                  </h1>
                  <h2 className="text-base sm:text-lg font-bold tracking-wide mt-0.5">
                    DELIVERY CHALAN/TRUCK CHALAN
                  </h2>
                </div>

                <div className="grid grid-cols-2 border-b border-black text-[11px]">
                  <div className="p-2 border-r border-black space-y-0.5">
                    <div className="font-bold">SHIPPER/EXPORTER</div>
                    <div className="font-bold">{data.exporter.name}</div>
                    <div>1,NO SADHU MADBOR ROAD,MAMUDPUR,</div>
                    <div>BHUIGHAR,FATULLAH,NARAYONGONJ.</div>
                  </div>
                  <div className="text-[11px]">
                    <div className="flex justify-between p-2 border-b border-black">
                      <span className="font-bold">
                        DELIVERY CHALLAN NO. <span className="font-normal ml-2">{data.challanNo}</span>
                      </span>
                      <span>Date.{data.challanDate}</span>
                    </div>
                    <div className="p-2">
                      <span className="font-bold">
                        L/C NO. {data.lcNo} Date.{data.lcDate}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 border-b border-black text-[11px]">
                  <div className="p-2 border-r border-black space-y-0.5">
                    <div className="font-bold">CONSIGNEE OR ORDER :</div>
                    <div className="font-bold">TO THE ORDER OF</div>
                    {appBankName && (
                      <div className="font-bold text-[10px]">
                        A/C NO:- {appBankName}
                        {appBankBranch ? `, ${appBankBranch}` : ''}{' '}
                        {appBankAddress && `, ${appBankAddress}`}
                      </div>
                    )}
                    <div className="font-bold pt-1">NOTIFY PARTY/APPLICANT.:</div>
                    <div className="font-bold">{applicantName}</div>
                    <div>{applicantAddress}</div>
                    {(postPart || psPart) && (
                      <div>
                        {postPart}
                        {postPart && psPart ? ', ' : ''}
                        {psPart}, {districtPart}
                      </div>
                    )}
                  </div>
                  <div className="divide-y divide-black text-[10.5px]">
                    <div className="p-1.5 font-bold">
                      EXPORT SC/LC NO. {data.exportScLcNo} Dt.{data.exportScLcDate}
                    </div>
                    <div className="p-1.5 font-bold">
                      BENEFICIARY BIN NO.{data.exporter.beneficiaryBin}
                    </div>
                    <div className="p-1.5 font-bold">
                      BANK VAT REG.NO. {data.exporter.bankVatRegNo}
                    </div>
                    <div className="p-1.5 font-bold">IRC NO.{data.exporter.ircNo}</div>
                    <div className="p-1.5 font-bold">
                      T/R NO.: {data.truckReceiptNo} Date.{data.truckReceiptDate}
                    </div>
                    <div className="p-1.5 font-bold">SHIPMENT PER : BY TRUCK</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 border-b border-black text-[11px] p-1.5 font-bold">
                  <div>PORT OF LOADING : BENEFICIARY'S FACTORY</div>
                  <div>FINAL DESTINATION : OPENER'S FACTORY SITE</div>
                </div>

                {/* Table */}
                <table className="w-full border-collapse text-[10.5px]">
                  <thead>
                    <tr className="border-b border-black text-center font-bold">
                      <th className="p-1.5 border-r border-black w-12">SL NO</th>
                      <th className="p-1.5 border-r border-black text-left">PARTICULARS</th>
                      <th className="p-1.5 border-r border-black w-24">EACH</th>
                      <th className="p-1.5 border-r border-black w-28">Quantity</th>
                      <th className="p-1.5 w-32 text-right pr-2">
                        Total/Quantity/Gyd/Yds/Dzn./Pcs.
                      </th>
                    </tr>
                    <tr className="border-b border-black">
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black text-left font-bold underline pl-2">
                        {data.itemsCategory || 'GARMENTS ACCESSORIES'}
                      </th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1 border-r border-black"></th>
                      <th className="p-1"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((it, idx) => (
                      <tr key={idx} className="border-b border-black/40">
                        <td className="p-1 border-r border-black text-center">{it.itemNo}</td>
                        <td className="p-1 border-r border-black font-medium">{it.particulars}</td>
                        <td className="p-1 border-r border-black text-center">
                          {it.eachPkg || '1000 Pkg'}
                        </td>
                        <td className="p-1 border-r border-black text-right pr-2 font-mono">
                          {it.quantity.toLocaleString()} {it.unit}
                        </td>
                        <td className="p-1 text-right pr-2 font-mono font-bold">
                          {it.quantity.toLocaleString()} {it.unit}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Total */}
                <div className="grid grid-cols-[1fr_auto_auto] border-t border-b border-black p-1.5 font-bold text-[11px]">
                  <div></div>
                  <div className="pr-12">{data.totalPkgCount || '8000 Pkg'}</div>
                  <div className="pr-2">
                    {data.totalQuantity.toLocaleString()} {data.totalQuantityUnit}
                  </div>
                </div>

                {/* Sign-off */}
                <div className="p-6 pt-12 flex flex-col items-end text-[11px] font-bold">
                  <div className="w-56 text-left">
                    <div>For,</div>
                    <div>SEVEN CLASSIC INDUSTRIES LTD.</div>
                    <div className="mt-12">AUTHORIZED SIGNATURE</div>
                  </div>
                </div>

                {/* 3-Line Footer */}
                <div className="border-t border-black p-2 text-[8.5px] font-bold space-y-0.5">
                  <div>HEAD OFFICE : {data.exporter.headOffice}</div>
                  <div>FACTORY : {data.exporter.factory}</div>
                  <div>
                    CELL : {data.exporter.cell}. Email : {data.exporter.email}
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================
                4. BILL OF EXCHANGE (FIRST & SECOND)
            ======================================================== */}
            {activeType === 'BILL_OF_EXCHANGE' && (
              <div className="space-y-10 py-2">
                {[1, 2].map((partNum) => (
                  <div key={partNum} className="space-y-2">
                    <div className="text-center">
                      <h2 className="text-2xl font-black italic tracking-wide text-black">
                        BILL OF EXCHANGE
                      </h2>
                    </div>

                    <div className="flex items-stretch gap-3 text-[11px] min-h-[300px]">
                      {/* Left vertical bordered box */}
                      <div className="w-11 border border-black flex items-center justify-center p-1 shrink-0">
                        <div className="rotate-[-90deg] whitespace-nowrap text-center">
                          <div className="font-bold text-[11px] tracking-wider uppercase text-black">
                            SEVEN CLASSIC INDUSTRIES LTD.
                          </div>
                          <div className="text-[7.5px] text-black">
                            1,NO.SADHU MADBOR,ROAD,MAMUDPUR,BHUIGHAR,FATULLAH, NARA YONGONJ.
                          </div>
                        </div>
                      </div>

                      {/* Right unbordered content area */}
                      <div className="flex-1 space-y-1.5 pl-1 relative">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1 pt-1">
                            <div className="flex gap-14">
                              <span className="font-bold">
                                P/I NO.: <span className="font-bold ml-4">{data.piNo || '145/2026'}</span>
                              </span>
                              <span className="font-bold">Date.{data.piDate || '19/08/2026'}</span>
                            </div>
                            <div className="font-bold text-xs pt-0.5">
                              EXCHANGE FOR (USD):{' '}
                              <span className="font-bold ml-6">
                                $
                                {data.totalAmount.toLocaleString(undefined, {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2,
                                })}
                              </span>
                            </div>
                          </div>

                          {/* 3D Stylized Number "1" or "2" */}
                          <div className="relative select-none pr-4">
                            <span className="text-5xl font-black italic text-sky-700 tracking-tighter drop-shadow-[2px_2px_0px_rgba(186,215,245,0.9)]">
                              {partNum}
                            </span>
                          </div>
                        </div>

                        {/* Sight Draft Paragraph */}
                        <div className="text-[10.5px] space-y-0.5 pt-1">
                          <div className="italic text-black font-serif">
                            {partNum === 1
                              ? 'At Sight of this FIRST Bill of Exchange (SECOND of the same tenor and date being-unpaid)'
                              : 'At Sight of this SECOND Bill of Exchange (FIRST of the same tenor and date being-unpaid)'}
                          </div>
                          <div>
                            pay to the order of "{data.negotiatingBank.name || 'SOUTHEAST BANK PLC.'},
                            {data.negotiatingBank.branch || 'MOUCHAK BRANCH'},
                          </div>
                          <div className="flex justify-between max-w-[500px]">
                            <span>{data.negotiatingBank.city || 'DHAKA,BANGLADESH.'}"</span>
                            <span className="pl-4">The sum of U.S. Dollar</span>
                          </div>
                          <div className="font-bold uppercase tracking-wide pl-2 pt-0.5 text-black">
                            {data.amountInWords}
                          </div>
                        </div>

                        {/* Value Received Clause */}
                        <div className="text-[10px] pt-1">
                          <div>Value Received Against Shipment of AS PER DELIVERY CHALLAN NO.:</div>
                          <div className="font-bold">
                            {data.challanNo || '145/2026'}{' '}
                            <span className="ml-8 font-bold">Date.{data.challanDate || '31/08/2026'}</span>
                          </div>
                        </div>

                        {/* Lower Split Columns */}
                        <div className="grid grid-cols-2 gap-4 pt-1.5 text-[10px]">
                          <div>
                            <div className="text-[9.5px]">to the account of and issued by :</div>
                            <div className="font-bold text-xs mt-2">TO :</div>
                            <div className="font-bold text-[11px]">{applicantName}</div>
                            <div>{applicantAddress}</div>
                            {(postPart || psPart) && (
                              <div>
                                {postPart}
                                {postPart && psPart ? ', ' : ''}
                                {psPart}, {districtPart}, {countryPart}.
                              </div>
                            )}
                            {appBankName && (
                              <div className="font-bold text-[8.5px] mt-1 text-black">
                                A/C NO:- {appBankName}
                                {appBankBranch ? `, ${appBankBranch}` : ''}{' '}
                                {appBankAddress && `, ${appBankAddress}`}
                              </div>
                            )}
                          </div>

                          <div className="space-y-0.5 text-[10px] font-medium pt-0">
                            <div>
                              L/C NO. {data.lcNo} <span className="ml-4">Date.{data.lcDate}</span>
                            </div>
                            <div>
                              EXPORT SC/LC NO. {data.exportScLcNo} Dt.{data.exportScLcDate}
                            </div>
                            <div>BENEFICIARY BIN NO.{data.exporter.beneficiaryBin}</div>
                            <div>BANK VAT REG.NO. {data.exporter.bankVatRegNo}</div>
                            <div>IRC NO.{data.exporter.ircNo}</div>

                            <div className="pt-3 font-bold text-[10px] text-left">
                              <div>For,</div>
                              <div>{data.exporter.name}</div>
                              <div className="pt-7 text-[8.5px] tracking-wider uppercase">
                                AUTHORIZED SIGNATURE
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ========================================================
                5. CERTIFICATE OF ORIGIN PREVIEW
            ======================================================== */}
            {activeType === 'CERTIFICATE_OF_ORIGIN' && (
              <div className="space-y-4 p-4 text-[11px]">
                <div className="text-center space-y-1">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                    SEVEN CLASSIC INDUSTRIES LTD.
                  </h1>
                  <h2 className="text-base font-bold underline">CERTIFICATE OF ORIGIN</h2>
                </div>

                <div className="pt-2">Date.{data.invoiceDate}</div>

                <div className="space-y-1.5 pt-2">
                  <div className="font-bold">1 Supplier's Name</div>
                  <div className="font-bold">2 SEVEN CLASSIC INDUSTRIES LTD.</div>
                  <div className="pl-4">
                    1,NO SADHU MADBOR ROAD,MAMUDPUR, BHUIGHAR,FATULLAH,NARAYONGONJ.
                  </div>

                  <div className="font-bold pt-2">3 Applicant /Buyer's Name</div>
                  <div className="font-bold">4 {applicantName}</div>
                  <div className="pl-4">5 {applicantAddress}</div>
                  {(postPart || psPart) && (
                    <div className="pl-4">
                      6 {postPart}, {psPart}, {districtPart}, {countryPart}.
                    </div>
                  )}
                </div>

                <div className="space-y-1 pt-2 text-[10.5px]">
                  <div>
                    L/C NO. {data.lcNo} Date.{data.lcDate}
                  </div>
                  <div>
                    EXPORT SC/LC NO. {data.exportScLcNo} Dt.{data.exportScLcDate}
                  </div>
                  <div>BENEFICIARY BIN NO.{data.exporter.beneficiaryBin}</div>
                  <div>BANK VAT REG.NO. {data.exporter.bankVatRegNo}</div>
                  <div>IRC NO.{data.exporter.ircNo}</div>
                </div>

                <div className="space-y-2 pt-4">
                  <div className="flex">
                    <span className="w-8 font-bold">8</span>{' '}
                    <span className="w-56">Quantity of Goods</span> <span className="w-4">:</span>{' '}
                    <span className="font-bold">
                      {data.totalQuantity} {data.totalQuantityUnit}
                    </span>
                  </div>
                  <div className="flex">
                    <span className="w-8 font-bold">9</span>{' '}
                    <span className="w-56">Invoice No. and Date</span> <span className="w-4">:</span>{' '}
                    <span className="font-bold">
                      {data.invoiceNo} Date.{data.invoiceDate}
                    </span>
                  </div>
                  <div className="flex">
                    <span className="w-8 font-bold">10</span>{' '}
                    <span className="w-56">Truck Receip No. and Date.</span>{' '}
                    <span className="w-4">:</span>{' '}
                    <span className="font-bold">
                      T/R NO.: {data.truckReceiptNo} Date.{data.truckReceiptDate}
                    </span>
                  </div>
                  <div className="flex">
                    <span className="w-8 font-bold">11</span>{' '}
                    <span className="w-56">Invoice Value</span> <span className="w-4">:</span>{' '}
                    <span className="font-bold">
                      $
                      {data.totalAmount.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="flex">
                    <span className="w-8 font-bold">12</span>{' '}
                    <span className="w-56">Applicant's Bin</span> <span className="w-4">:</span>{' '}
                    <span className="font-bold">
                      BENEFICIARY BIN NO.{data.exporter?.beneficiaryBin}
                    </span>
                  </div>
                  <div className="flex">
                    <span className="w-8 font-bold">13</span>{' '}
                    <span className="w-56">Bank Vat Reg. No.</span> <span className="w-4">:</span>{' '}
                    <span className="font-bold">
                      BANK VAT REG.NO. {data.exporter?.bankVatRegNo}
                    </span>
                  </div>
                </div>

                <div className="pt-4">
                  <div>
                    This is to Certify That Merchandise Delivered/Supplied to the above Mentioned
                  </div>
                  <div>Buyers Are of Bangladesh Origin</div>
                </div>

                <div className="pt-16 font-bold space-y-12">
                  <div>For : Seven Classic Industries Ltd.</div>
                  <div>Authorized Signature</div>
                </div>
              </div>
            )}

            {/* ========================================================
                6. BENEFICIARY'S CERTIFICATE PREVIEW
            ======================================================== */}
            {activeType === 'BENEFICIARY_CERT' && (
              <div className="space-y-6 p-6 text-[12px]">
                <div className="text-center space-y-2">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight underline">
                    SEVEN CLASSIC INDUSTRIES LTD.
                  </h1>
                  <h2 className="text-base font-bold underline">BENEFICIARY'S CERTIFICATE</h2>
                </div>

                <div className="pt-4">Date.{data.invoiceDate}</div>

                <div className="space-y-2 pt-2 leading-relaxed">
                  <div>
                    This is to certify that the goods shipped against P/I No. {data.piNo}
                  </div>
                  <div>Date.{data.piDate}</div>
                  <div>
                    L/C NO. {data.lcNo} Date.{data.lcDate}
                  </div>
                  <div>
                    EXPORT SC/LC NO. {data.exportScLcNo} Dt.{data.exportScLcDate}
                  </div>
                  <div>BENEFICIARY BIN NO.{data.exporter?.beneficiaryBin}</div>
                  <div>BANK VAT REG.NO. {data.exporter?.bankVatRegNo}</div>
                  <div>IRC NO.{data.exporter?.ircNo}</div>
                  <div className="pt-2">
                    Is Manufactured by us and is Completely of Bangladesh Origin.
                  </div>
                </div>

                <div className="pt-24 font-bold space-y-16">
                  <div>FOR, SEVEN CLASSIC INDUSTRIES LTD.</div>
                  <div>AUTHORIZED SIGNATURE</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
