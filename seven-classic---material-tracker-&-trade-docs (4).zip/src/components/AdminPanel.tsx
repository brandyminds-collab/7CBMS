import React, { useState, useEffect } from 'react';
import { DocTemplateType, MaterialItem, TradeDocumentData } from '../types';
import { AutoDocGenerator } from './AutoDocGenerator';
import {
  Package,
  FileText,
  History,
  Lock,
  Unlock,
  X,
  Edit2,
  Trash2,
  AlertCircle,
  Eye,
} from 'lucide-react';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  materials: MaterialItem[];
  onSaveMaterial: (material: MaterialItem) => void;
  onDeleteMaterial: (id: string) => void;
  onDeductStock: (materialId: string, qty: number) => void;
  onPreviewDoc: (data: TradeDocumentData, templateType: DocTemplateType) => void;
  onQuickPresetLoad: () => void;
}

const ADMIN_PASSWORD = 'seven8081';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  materials,
  onSaveMaterial,
  onDeleteMaterial,
  onDeductStock,
  onPreviewDoc,
  onQuickPresetLoad,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('sevenClassicAdminAuth') === 'true';
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState(false);

  // Active Admin Sub-Tab
  const [activeTab, setActiveTab] = useState<'inventory' | 'docgen' | 'history'>('inventory');

  // Inventory Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [maxQty, setMaxQty] = useState('');
  const [remainingBalance, setRemainingBalance] = useState('');
  const [unit, setUnit] = useState('Kg');
  const [unitPrice, setUnitPrice] = useState('');
  const [isBlue, setIsBlue] = useState(false);

  // Document History
  const [historyDocs, setHistoryDocs] = useState<TradeDocumentData[]>([]);

  useEffect(() => {
    if (isOpen) {
      const savedHistory = localStorage.getItem('sevenClassicTradeDocHistory');
      if (savedHistory) {
        try {
          setHistoryDocs(JSON.parse(savedHistory));
        } catch {
          setHistoryDocs([]);
        }
      }
    }
  }, [isOpen, activeTab]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setAuthError(false);
      localStorage.setItem('sevenClassicAdminAuth', 'true');
    } else {
      setAuthError(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sevenClassicAdminAuth');
    onClose();
  };

  const handleEditClick = (mat: MaterialItem) => {
    setEditingId(mat.id);
    setName(mat.name);
    setMaxQty(String(mat.maxQty));
    setRemainingBalance(String(mat.remainingBalance));
    setUnit(mat.unit);
    setUnitPrice(String(mat.unitPrice));
    setIsBlue(mat.isBlue);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setName('');
    setMaxQty('');
    setRemainingBalance('');
    setUnit('Kg');
    setUnitPrice('');
    setIsBlue(false);
  };

  const handleMaterialFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const maxQ = Number(maxQty);
    const remB = Number(remainingBalance);
    const uP = Number(unitPrice);

    if (!name.trim()) {
      alert('Please enter material name.');
      return;
    }
    if (maxQ <= 0) {
      alert('Total Lot Kg must be greater than 0.');
      return;
    }
    if (remB < 0) {
      alert('Remaining Balance cannot be negative.');
      return;
    }
    if (remB > maxQ) {
      alert('Remaining Balance cannot be greater than Total Lot Kg.');
      return;
    }
    if (uP < 0) {
      alert('Unit Price cannot be negative.');
      return;
    }

    const item: MaterialItem = {
      id: editingId || `mat-${Date.now()}`,
      name: name.trim().toUpperCase(),
      maxQty: maxQ,
      remainingBalance: remB,
      unit: unit.trim() || 'Kg',
      unitPrice: uP,
      isBlue: isBlue,
    };

    onSaveMaterial(item);
    handleCancelEdit();
  };

  if (!isOpen) return null;

  // Password gate if not logged in
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-xl p-6 shadow-2xl text-slate-100 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-sky-400 font-bold">
              <Lock className="w-5 h-5" /> Admin Inventory Verification
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-xs text-slate-400">
            Enter the admin password to access raw material editing and inventory controls:
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Admin Password
              </label>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => {
                  setPasswordInput(e.target.value);
                  setAuthError(false);
                }}
                placeholder="Enter password (e.g. seven8081)"
                autoFocus
                className="w-full bg-slate-950 border border-slate-700 focus:border-sky-500 rounded-lg p-2.5 text-sm font-mono text-white outline-none"
              />
              <div className="text-[11px] text-slate-500 mt-1">
                Default password: <span className="font-mono text-sky-400 font-semibold">seven8081</span>
              </div>
            </div>

            {authError && (
              <div className="p-2.5 rounded bg-rose-950/70 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400" />
                <span>Incorrect password! Please try again.</span>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold rounded bg-sky-600 hover:bg-sky-500 text-white transition flex items-center gap-1.5"
              >
                <Unlock className="w-3.5 h-3.5" /> Unlock Admin
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#1c212c] border-2 border-dashed border-[#3498db] rounded-xl p-5 mb-8 text-slate-100 shadow-2xl">
      {/* Admin Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-700/80 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400 font-black text-lg">
            7C
          </div>
          <div>
            <div className="text-base font-bold text-sky-400 uppercase tracking-wider flex items-center gap-2">
              Seven Classic Management Console
              <span className="text-emerald-400 text-xs font-normal normal-case flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Admin Mode Active
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Live Raw Material Balance Tracking & Automatic Trade Document (LC / PI) PDF Generation
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleLogout}
            className="px-3.5 py-1.5 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            Lock Admin
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-bold rounded bg-rose-900/80 hover:bg-rose-800 text-rose-200 transition"
          >
            Close Panel
          </button>
        </div>
      </div>

      {/* Admin Sub Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 my-4 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold tracking-wide transition ${
            activeTab === 'inventory'
              ? 'bg-sky-600 text-white shadow'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Package className="w-4 h-4 text-sky-200" />
          <span>Raw Materials Inventory & Entry Form</span>
        </button>
        <button
          onClick={() => setActiveTab('docgen')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold tracking-wide transition ${
            activeTab === 'docgen'
              ? 'bg-sky-600 text-white shadow'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <FileText className="w-4 h-4 text-sky-200" />
          <span>Auto Document Generator (LC / PI)</span>
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold tracking-wide transition ${
            activeTab === 'history'
              ? 'bg-sky-600 text-white shadow'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <History className="w-4 h-4 text-sky-200" />
          <span>Trade Documents Archive ({historyDocs.length})</span>
        </button>
      </div>

      {/* TAB CONTENT 1: INVENTORY ENTRY FORM */}
      {activeTab === 'inventory' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 rounded-xl p-5 border border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-sky-400 uppercase tracking-wider">
                {editingId ? 'Edit Raw Material Item' : 'Add New Raw Material Entry'}
              </h3>
              <button
                type="button"
                onClick={onQuickPresetLoad}
                className="text-xs text-sky-400 hover:text-sky-300 underline font-medium"
              >
                Reset Standard Paper Presets
              </button>
            </div>

            <form onSubmit={handleMaterialFormSubmit}>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 mb-4">
                {/* Material Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-semibold">Material Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    placeholder="e.g. Duplex Board 350 GSM"
                    className="w-full bg-[#13161c] border border-[#2c313d] text-white p-2.5 rounded text-sm focus:border-sky-500 outline-none"
                  />
                </div>

                {/* Total Kg */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-semibold">
                    Total Kg (Capacity / Lot)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={maxQty}
                    onChange={(e) => setMaxQty(e.target.value)}
                    required
                    placeholder="e.g. 10000"
                    className="w-full bg-[#13161c] border border-[#2c313d] text-white p-2.5 rounded text-sm focus:border-sky-500 outline-none"
                  />
                </div>

                {/* Remaining Balance */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-semibold">Remaining Balance</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={remainingBalance}
                    onChange={(e) => setRemainingBalance(e.target.value)}
                    required
                    placeholder="e.g. 6000"
                    className="w-full bg-[#13161c] border border-[#2c313d] text-white p-2.5 rounded text-sm focus:border-sky-500 outline-none"
                  />
                </div>

                {/* Unit */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-semibold">Unit</label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    required
                    placeholder="Kg"
                    className="w-full bg-[#13161c] border border-[#2c313d] text-white p-2.5 rounded text-sm focus:border-sky-500 outline-none"
                  />
                </div>

                {/* Unit Price */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-semibold">Unit Price ($)</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={unitPrice}
                    onChange={(e) => setUnitPrice(e.target.value)}
                    required
                    placeholder="e.g. 0.80"
                    className="w-full bg-[#13161c] border border-[#2c313d] text-white p-2.5 rounded text-sm focus:border-sky-500 outline-none"
                  />
                </div>

                {/* Highlight Blue */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-semibold">Highlight Blue?</label>
                  <select
                    value={isBlue ? 'true' : 'false'}
                    onChange={(e) => setIsBlue(e.target.value === 'true')}
                    className="w-full bg-[#13161c] border border-[#2c313d] text-white p-2.5 rounded text-sm focus:border-sky-500 outline-none"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider transition"
                >
                  {editingId ? 'Update Material' : 'Save Material'}
                </button>
                {editingId && (
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="px-4 py-2.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold transition"
                  >
                    Cancel Edit
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Existing Inventory Quick List */}
          <div className="bg-slate-900/90 rounded-xl p-5 border border-slate-800">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
              Configured Raw Materials ({materials.length})
            </h3>
            <div className="divide-y divide-slate-800">
              {materials.map((mat) => (
                <div key={mat.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className={`font-bold ${mat.isBlue ? 'text-sky-400' : 'text-white'}`}>
                      {mat.name}
                    </span>
                    <span className="text-slate-400 ml-2">
                      ({mat.remainingBalance.toLocaleString()} / {mat.maxQty.toLocaleString()}{' '}
                      {mat.unit} @ ${mat.unitPrice.toFixed(2)})
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEditClick(mat)}
                      className="px-2.5 py-1 rounded bg-amber-600/30 hover:bg-amber-600 text-amber-200 hover:text-white transition flex items-center gap-1"
                    >
                      <Edit2 className="w-3 h-3" /> Edit
                    </button>
                    <button
                      onClick={() => onDeleteMaterial(mat.id)}
                      className="px-2.5 py-1 rounded bg-rose-600/30 hover:bg-rose-600 text-rose-200 hover:text-white transition flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: AUTO DOCUMENT GENERATOR */}
      {activeTab === 'docgen' && (
        <AutoDocGenerator
          materials={materials}
          onDeductMaterialStock={onDeductStock}
          onPreviewDoc={onPreviewDoc}
        />
      )}

      {/* TAB CONTENT 3: HISTORY & ARCHIVE */}
      {activeTab === 'history' && (
        <div className="bg-slate-900/90 rounded-xl p-5 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Generated Trade Documents History
            </h3>
            {historyDocs.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('Clear document generation history?')) {
                    localStorage.removeItem('sevenClassicTradeDocHistory');
                    setHistoryDocs([]);
                  }
                }}
                className="text-[11px] text-rose-400 hover:underline"
              >
                Clear History
              </button>
            )}
          </div>

          {historyDocs.length === 0 ? (
            <div className="p-8 text-center border border-dashed border-slate-800 rounded-lg text-slate-500 text-xs">
              No document history yet. Upload an LC or PI to create drafts.
            </div>
          ) : (
            <div className="space-y-2.5">
              {historyDocs.map((doc, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{doc.buyer?.name || 'Buyer'}</span>
                      <span className="font-mono text-sky-400 bg-sky-950/60 px-1.5 py-0.5 rounded border border-sky-800 text-[10px]">
                        {doc.lcNo || 'LC'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">
                      Invoice: {doc.invoiceNo} | Value: ${doc.totalAmount?.toLocaleString()} USD |
                      Date: {doc.invoiceDate || 'Recently'}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onPreviewDoc(doc, 'COMMERCIAL_INVOICE')}
                      className="px-3 py-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white font-bold transition flex items-center gap-1.5"
                    >
                      <Eye className="w-3.5 h-3.5" /> View & Print
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
