import { useState, useEffect } from 'react';
import { MaterialItem, TradeDocumentData, DocTemplateType } from './types';
import { INITIAL_MATERIALS } from './utils/sampleData';
import { TrackerDashboard } from './components/TrackerDashboard';
import { AutoDocGenerator } from './components/AutoDocGenerator';
import { AdminPanel } from './components/AdminPanel';
import { DocPreviewModal } from './components/DocPreviewModal';
import { Layers, FileText, Lock } from 'lucide-react';

const STORAGE_KEY = 'sevenClassicMaterials';

export default function App() {
  const [materials, setMaterials] = useState<MaterialItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return INITIAL_MATERIALS;
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item: any, idx: number) => ({
          id: item.id || `mat-${idx}`,
          name: item.name || 'Unnamed Material',
          maxQty: Number(item.maxQty) || 10000,
          remainingBalance: Number(item.remainingBalance ?? item.currentQty) || 0,
          unit: item.unit || 'Kg',
          unitPrice: Number(item.unitPrice) || 0,
          isBlue: Boolean(item.isBlue),
        }));
      }
      return INITIAL_MATERIALS;
    } catch {
      return INITIAL_MATERIALS;
    }
  });

  // Main navigation tab: 'docgen' or 'tracker'
  const [mainTab, setMainTab] = useState<'docgen' | 'tracker'>('docgen');
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    return localStorage.getItem('sevenClassicAdminAuth') === 'true';
  });

  // Modal preview state
  const [previewDocState, setPreviewDocState] = useState<{
    data: TradeDocumentData;
    templateType: DocTemplateType;
  } | null>(null);

  // Notification badge
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(materials));
  }, [materials]);

  // Keep admin logged-in state in sync
  useEffect(() => {
    const checkAuth = () => {
      setIsAdminLoggedIn(localStorage.getItem('sevenClassicAdminAuth') === 'true');
    };
    window.addEventListener('storage', checkAuth);
    return () => window.removeEventListener('storage', checkAuth);
  }, []);

  const handleSaveMaterial = (item: MaterialItem) => {
    setMaterials((prev) => {
      const existsIndex = prev.findIndex((m) => m.id === item.id);
      if (existsIndex >= 0) {
        const copy = [...prev];
        copy[existsIndex] = item;
        showToast(`"${item.name}" updated successfully.`);
        return copy;
      } else {
        showToast(`"${item.name}" added successfully.`);
        return [...prev, item];
      }
    });
  };

  const handleDeleteMaterial = (id: string) => {
    const target = materials.find((m) => m.id === id);
    if (!target) return;
    if (confirm(`Are you sure you want to delete "${target.name}"?`)) {
      setMaterials((prev) => prev.filter((m) => m.id !== id));
      showToast(`"${target.name}" deleted.`);
    }
  };

  const handleDeductStock = (id: string, deductQty: number) => {
    setMaterials((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const newBal = Math.max(0, m.remainingBalance - deductQty);
          return { ...m, remainingBalance: newBal };
        }
        return m;
      })
    );
    showToast(`Allocated ${deductQty.toLocaleString()} units deducted from inventory.`);
  };

  const handleResetPresets = () => {
    if (confirm('Reset raw materials to standard packaging presets?')) {
      setMaterials(INITIAL_MATERIALS);
      showToast('Inventory reset to standard presets.');
    }
  };

  return (
    <div className="min-h-screen bg-[#14171e] text-white py-6 px-3 sm:px-6">
      <div className="max-w-[1240px] mx-auto space-y-6">
        {/* Toast Alert */}
        {toastMessage && (
          <div className="fixed top-4 right-4 z-50 bg-slate-900 border border-sky-500/50 text-sky-200 px-4 py-2.5 rounded-lg shadow-2xl text-xs font-semibold flex items-center gap-2 animate-fade-in">
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Global Brand Header & Navigation Tabs */}
        <header className="bg-[#1a1e28] border border-[#2b3140] rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-sky-500 to-blue-700 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-sky-900/40">
              7C
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-white tracking-wide">
                  SEVEN CLASSIC INDUSTRIES LTD.
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30 uppercase">
                  Commercial Suite
                </span>
              </div>
              <p className="text-xs text-slate-400">
                1, No. Sadhu Madbor Road, Mamudpur, Bhuighar, Fatullah, Narayanganj
              </p>
            </div>
          </div>

          {/* Navigation Switcher */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="bg-[#12151c] p-1 rounded-xl border border-[#2c3242] flex items-center">
              <button
                onClick={() => setMainTab('docgen')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition ${
                  mainTab === 'docgen'
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-900/50'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4 text-sky-300" />
                <span>LC / PI Auto Generator</span>
              </button>
              <button
                onClick={() => setMainTab('tracker')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition ${
                  mainTab === 'tracker'
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-900/50'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="w-4 h-4 text-sky-300" />
                <span>Raw Material Tracker</span>
              </button>
            </div>

            <button
              onClick={() => setIsAdminOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#202532] hover:bg-[#282f40] text-slate-300 hover:text-white border border-[#31384a] text-xs font-semibold transition"
            >
              <Lock className="w-3.5 h-3.5 text-sky-400" />
              <span>Admin</span>
            </button>
          </div>
        </header>

        {/* Admin Panel Modal / Drawer */}
        {isAdminOpen && (
          <AdminPanel
            isOpen={isAdminOpen}
            onClose={() => setIsAdminOpen(false)}
            materials={materials}
            onSaveMaterial={handleSaveMaterial}
            onDeleteMaterial={handleDeleteMaterial}
            onDeductStock={handleDeductStock}
            onPreviewDoc={(data, templateType) => setPreviewDocState({ data, templateType })}
            onQuickPresetLoad={handleResetPresets}
          />
        )}

        {/* View 1: AUTO DOCUMENT GENERATOR (Upload LC & PI -> Auto Generate 6 Docs) */}
        {mainTab === 'docgen' && (
          <div className="space-y-4">
            <AutoDocGenerator
              materials={materials}
              onDeductMaterialStock={handleDeductStock}
              onPreviewDoc={(data, templateType) => setPreviewDocState({ data, templateType })}
            />
          </div>
        )}

        {/* View 2: LIVE RAW MATERIAL BALANCE TRACKER DASHBOARD */}
        {mainTab === 'tracker' && (
          <TrackerDashboard
            materials={materials}
            isAdminLoggedIn={isAdminLoggedIn}
            onOpenAdmin={() => setIsAdminOpen(true)}
            onEditMaterial={() => {
              setIsAdminOpen(true);
            }}
            onDeleteMaterial={handleDeleteMaterial}
            onQuickOpenDocGen={() => {
              setMainTab('docgen');
            }}
          />
        )}

        {/* Paper Document Preview & PDF Download Modal */}
        {previewDocState && (
          <DocPreviewModal
            data={previewDocState.data}
            initialType={previewDocState.templateType}
            onClose={() => setPreviewDocState(null)}
          />
        )}
      </div>
    </div>
  );
}
