export interface MaterialItem {
  id: string;
  name: string;
  maxQty: number;
  remainingBalance: number;
  unit: string;
  unitPrice: number;
  isBlue: boolean;
}

export interface TradeItem {
  itemNo: number;
  particulars: string; // Description e.g. Twill Tape Wide: 2.00 Inch 481 gsm
  eachPkg?: string; // e.g. "3000 Pkg" or "1000 Pkg"
  quantity: number; // e.g. 1388
  unit: string; // Gyds, Mtr., Pcs, Yds, Dzn
  unitPrice: number; // e.g. 5.1932
  totalAmount: number; // e.g. 7208.18
  ctnNo?: string; // e.g. 145/2026
}

export interface TradeDocumentData {
  id?: string;
  documentType: 'LC' | 'PI' | 'SALES_CONTRACT';

  // Document Numbers & Dates
  invoiceNo: string;
  invoiceDate: string;
  challanNo: string;
  challanDate: string;
  lcNo: string;
  lcDate: string;
  exportScLcNo: string;
  exportScLcDate: string;
  piNo: string;
  piDate: string;

  // Shipper / Exporter
  exporter: {
    name: string;
    factory: string;
    headOffice: string;
    beneficiaryBin: string;
    bankVatRegNo: string;
    ircNo: string;
    cell: string;
    email: string;
  };

  // Consignee / Buyer / Applicant
  buyer: {
    name: string;
    address: string;
    plotNo: string;
    post: string;
    ps: string;
    district: string;
    country: string;
  };

  // Optional distinct Notify Party
  notifyParty?: {
    name: string;
    address: string;
  };

  // Applicant's Bank / Consignee Bank / LC Issuing Bank (A/C Bank from LC)
  applicantBank?: {
    bankName: string;
    branch: string;
    address: string;
    accountNo?: string;
  };

  // Exporter's Banking Details
  exporterBankAccount: {
    bankName: string;
    branch: string;
    address: string;
    swiftCode?: string;
  };

  negotiatingBank: {
    name: string;
    branch: string;
    city: string;
  };

  // Transport & Shipment
  truckReceiptNo: string;
  truckReceiptDate: string;
  portOfLoading: string;
  finalDestination: string;
  carrier: string;
  terms: string;
  sailingAbout: string;

  // Items & Values
  itemsCategory: string; // e.g. "GARMENTS ACCESSORIES"
  items: TradeItem[];
  totalQuantity: number;
  totalQuantityUnit: string; // e.g. "Gyds/Mtr/Pcs"
  totalPkgCount?: string; // e.g. "30000 Pkg"
  totalAmount: number;
  amountInWords: string;
  generatedAt?: string;
}

export type DocTemplateType =
  | 'COMMERCIAL_INVOICE'
  | 'PACKING_LIST'
  | 'DELIVERY_CHALLAN'
  | 'BILL_OF_EXCHANGE'
  | 'CERTIFICATE_OF_ORIGIN'
  | 'BENEFICIARY_CERT';
