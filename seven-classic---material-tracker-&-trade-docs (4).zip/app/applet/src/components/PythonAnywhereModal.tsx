import React, { useState } from 'react';
import { X, Server, Copy, Check, Download, Terminal, Globe, ShieldCheck } from 'lucide-react';

interface PythonAnywhereModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonAnywhereModal: React.FC<PythonAnywhereModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'app.py' | 'wsgi.py' | 'requirements.txt'>('guide');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const appPyCode = `import os
import base64
from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
from google.genai import types

app = Flask(__name__)
CORS(app)

api_key = os.environ.get("GEMINI_API_KEY")
client = genai.Client(api_key=api_key) if api_key else genai.Client()

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "running", "platform": "PythonAnywhere", "model": "gemini-3.8-flash"})

@app.route('/api/extract-document', methods=['POST'])
def extract_document():
    try:
        data = request.json or {}
        lc_file_base64 = data.get('lcFileBase64')
        lc_mime_type = data.get('lcMimeType', 'application/pdf')
        lc_file_name = data.get('lcFileName', 'LC.pdf')
        
        pi_file_base64 = data.get('piFileBase64')
        pi_mime_type = data.get('piMimeType', 'application/pdf')
        pi_file_name = data.get('piFileName', 'PI.pdf')
        
        file_base64 = data.get('fileBase64')
        mime_type = data.get('mimeType', 'application/pdf')
        file_name = data.get('fileName', 'document.pdf')
        
        text_content = data.get('textContent', '')
        prompt_text = data.get('prompt', 'Extract all commercial trade details, buyer, items, and bank info into strict JSON.')

        prompt_system_instructions = "You are an expert Trade Document AI Assistant for Seven Classic Industries Ltd., Bangladesh. Extract all details into strict JSON matching the required schema."

        parts = []
        if lc_file_base64:
            clean_base64 = lc_file_base64.split(',')[-1]
            parts.append(types.Part.from_bytes(data=base64.b64decode(clean_base64), mime_type=lc_mime_type))
            parts.append(types.Part.from_text(text=f"LC file '{lc_file_name}'"))

        if pi_file_base64:
            clean_base64 = pi_file_base64.split(',')[-1]
            parts.append(types.Part.from_bytes(data=base64.b64decode(clean_base64), mime_type=pi_mime_type))
            parts.append(types.Part.from_text(text=f"PI file '{pi_file_name}'"))

        if text_content:
            parts.append(types.Part.from_text(text=f"SWIFT Content:\\n{text_content}"))

        parts.append(types.Part.from_text(text=prompt_text))

        response = client.models.generate_content(
            model='gemini-3.8-flash',
            contents=parts,
            config=types.GenerateContentConfig(
                system_instruction=prompt_system_instructions,
                response_mime_type='application/json',
            )
        )

        import json
        output_text = response.text or '{}'
        try:
            parsed_data = json.loads(output_text)
        except Exception:
            import re
            match = re.search(r'\\{[\\s\\S]*\\}', output_text)
            parsed_data = json.loads(match.group(0)) if match else {"error": "Failed to parse JSON"}

        return jsonify({"success": True, "data": parsed_data, "source": "pythonanywhere_gemini_ai"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)`;

  const wsgiPyCode = `import sys
import os

# Replace 'YOUR_PYTHONANYWHERE_USERNAME' with your PythonAnywhere username
path = '/home/YOUR_PYTHONANYWHERE_USERNAME/mysite'
if path not in sys.path:
    sys.path.append(path)

from app import app as application`;

  const requirementsCode = `flask>=3.0.0
flask-cors>=4.0.0
google-genai>=1.0.0
python-dotenv>=1.0.0`;

  const getCurrentContent = () => {
    if (activeTab === 'app.py') return appPyCode;
    if (activeTab === 'wsgi.py') return wsgiPyCode;
    if (activeTab === 'requirements.txt') return requirementsCode;
    return '';
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCurrentContent());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="bg-[#1a1e28] border border-[#2e3648] w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-[#141821] px-6 py-4 border-b border-[#2b3344] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-lg">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                PythonAnywhere AI Server Deployment
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                  Ready
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Deploy your Seven Classic AI extraction backend to PythonAnywhere (Flask + Google GenAI SDK)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#222836] hover:bg-[#2b3344] text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className="bg-[#141821] px-6 border-b border-[#2b3344] flex gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'guide'
                ? 'border-sky-500 text-sky-400 bg-[#1a1e28]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Deployment Guide (বাংলা / English)</span>
          </button>
          <button
            onClick={() => setActiveTab('app.py')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'app.py'
                ? 'border-sky-500 text-sky-400 bg-[#1a1e28]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>app.py (Flask Server)</span>
          </button>
          <button
            onClick={() => setActiveTab('wsgi.py')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'wsgi.py'
                ? 'border-sky-500 text-sky-400 bg-[#1a1e28]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>wsgi.py (WSGI Config)</span>
          </button>
          <button
            onClick={() => setActiveTab('requirements.txt')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'requirements.txt'
                ? 'border-sky-500 text-sky-400 bg-[#1a1e28]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>requirements.txt</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 text-slate-200 space-y-4">
          {activeTab === 'guide' && (
            <div className="space-y-6 text-sm">
              <div className="bg-sky-500/10 border border-sky-500/30 rounded-xl p-4 text-sky-200">
                <h3 className="font-bold text-sm text-sky-300 mb-1 flex items-center gap-2">
                  <span>🚀 PythonAnywhere-এ এআই সার্ভার ডিপ্লয় করার সম্পূর্ণ নির্দেশিকা</span>
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  PythonAnywhere একটি পাইথন হোস্টিং প্ল্যাটফর্ম। আপনার এআই সার্ভারটি পাইথন Flask ও Google GenAI SDK দিয়ে তৈরি করা হয়েছে, যা পাইথনঅ্যানহোয়ারে খুব সহজে রান করা সম্ভব।
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div className="bg-[#13161f] p-4 rounded-xl border border-[#272e3d] space-y-2">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2 text-sky-400">
                    <span>ধাপ ১: PythonAnywhere অ্যাকাউন্ট ও ফাইল আপলোড</span>
                  </h4>
                  <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
                    <li>PythonAnywhere (pythonanywhere.com)-এ ফ্রি অ্যাকাউন্ট খুলে লগইন করুন।</li>
                    <li><strong className="text-white">Files</strong> ট্যাবে যান এবং <code className="bg-black/40 px-1.5 py-0.5 rounded text-sky-300">/home/yourusername/mysite/</code> ফোল্ডারে নিচে দেওয়া তিনটি ফাইল আপলোড করুন (<code className="text-sky-300">app.py</code>, <code className="text-sky-300">wsgi.py</code>, <code className="text-sky-300">requirements.txt</code>)।</li>
                  </ul>
                </div>

                <div className="bg-[#13161f] p-4 rounded-xl border border-[#272e3d] space-y-2">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2 text-sky-400">
                    <span>ধাপ ২: লাইব্রেরি ইন্সটল (Bash Console)</span>
                  </h4>
                  <p className="text-slate-300">Dashboard থেকে একটি নতুন <strong className="text-white">Bash console</strong> ওপেন করে নিচের কমান্ডগুলো চালান:</p>
                  <pre className="bg-black/60 p-3 rounded-lg text-sky-300 font-mono text-[11px] overflow-x-auto">
cd ~
mkvirtualenv --python=/usr/bin/python3.10 myenv
pip install -r mysite/requirements.txt
                  </pre>
                </div>

                <div className="bg-[#13161f] p-4 rounded-xl border border-[#272e3d] space-y-2">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2 text-sky-400">
                    <span>ধাপ ৩: Gemini API Key কনফিগারেশন</span>
                  </h4>
                  <p className="text-slate-300"><strong className="text-white">Web</strong> ট্যাবে গিয়ে আপনার WSGI configuration file-এ ক্লিক করুন এবং ফাইলের শুরুতে API Key যুক্ত করুন:</p>
                  <pre className="bg-black/60 p-3 rounded-lg text-emerald-300 font-mono text-[11px] overflow-x-auto">
import os
os.environ["GEMINI_API_KEY"] = "AIzaSyYourActualGeminiApiKeyHere"
                  </pre>
                </div>

                <div className="bg-[#13161f] p-4 rounded-xl border border-[#272e3d] space-y-2">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2 text-sky-400">
                    <span>ধাপ ৪: Web App রিলোড</span>
                  </h4>
                  <p className="text-slate-300">সবশেষে <strong className="text-white">Web</strong> ট্যাবে ফিরে গিয়ে বড় সবুজ রঙের <strong className="text-emerald-400">Reload yourusername.pythonanywhere.com</strong> বাটনে ক্লিক করুন। আপনার এআই সার্ভার লাইভ!</p>
                </div>
              </div>
            </div>
          )}

          {activeTab !== 'guide' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400">
                  File: <code className="text-sky-300">{activeTab}</code>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#222836] hover:bg-[#2b3344] text-slate-200 text-xs font-semibold transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-sky-400" />}
                    <span>{copied ? 'Copied!' : 'Copy Code'}</span>
                  </button>
                  <button
                    onClick={() => handleDownload(activeTab, getCurrentContent())}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition shadow-md"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download {activeTab}</span>
                  </button>
                </div>
              </div>

              <pre className="bg-[#12151c] border border-[#272e3d] p-4 rounded-xl font-mono text-xs text-sky-200 overflow-x-auto max-h-[50vh] leading-relaxed">
                {getCurrentContent()}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-[#141821] px-6 py-4 border-t border-[#2b3344] flex items-center justify-between">
          <p className="text-xs text-slate-400">
            Need help? Check files in <code className="text-sky-300">python_server/</code> folder.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition shadow-lg"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
