# PythonAnywhere Deployment Guide for Seven Classic AI Server

PythonAnywhere একটি জনপ্রিয় পাইথন হোস্টিং প্ল্যাটফর্ম। যেহেতু আপনার এআই সার্ভার পাইথন (`google-genai` SDK) দিয়ে তৈরি, তাই আপনি এই ফ্লাস্ক ব্যাকএন্ডটি পাইথনঅ্যানহোয়ারে খুব সহজেই ডিপ্লয় করতে পারবেন!

## PythonAnywhere-এ ডিপ্লয় করার ধাপসমূহ:

1. **অ্যাকাউন্ট তৈরি করুন:**
   - [PythonAnywhere](https://www.pythonanywhere.com/)-এ গিয়ে একটি ফ্রি অ্যাকাউন্ট তৈরি করুন।

2. **ফাইল আপলোড করুন:**
   - **Files** ট্যাবে যান।
   - `/home/yourusername/mysite/` ফোল্ডারে নিচের ফাইলগুলো আপলোড করুন:
     - `app.py`
     - `wsgi.py`
     - `requirements.txt`

3. **লাইব্রেরি ইন্সটল করুন (Bash Console থেকে):**
   - PythonAnywhere-এর একটি **Bash console** ওপেন করে নিচের কমান্ডগুলো চালান:
     ```bash
     cd ~
     mkvirtualenv --python=/usr/bin/python3.10 myenv
     pip install -r mysite/requirements.txt
     ```

4. **API Key সেট করুন:**
   - PythonAnywhere-এর **Web** ট্যাবে গিয়ে আপনার WSGI কনফিগারেশন ফাইল লিঙ্কে ক্লিক করুন (যেমন: `/var/www/yourusername_pythonanywhere_com_wsgi.py`)।
   - ফাইলের একেবারে উপরে আপনার Gemini API Key যোগ করুন:
     ```python
     import os
     os.environ["GEMINI_API_KEY"] = "আপনার_জেমিনি_এপিআই_কী_এখানে_দিন"
     ```

5. **WSGI ফাইল কনফিগার করুন (`wsgi.py`):**
   - `wsgi.py` ফাইলের মধ্যে আপনার আসল PythonAnywhere ইউজারনেম দিয়ে পাথ ঠিক করুন:
     ```python
     import sys
     import os

     path = '/home/yourusername/mysite'
     if path not in sys.path:
         sys.path.append(path)

     from app import app as application
     ```

6. **Web App রিলোড করুন:**
   - আবার **Web** ট্যাবে গিয়ে সবুজ রঙের **Reload yourusername.pythonanywhere.com** বাটনে ক্লিক করুন।
   - ব্যাস! আপনার এআই সার্ভার এখন `https://yourusername.pythonanywhere.com/api/extract-document` এ লাইভ হয়ে গেছে!
