import sys
import os

# Add your project directory to the sys.path
# Replace 'YOUR_PYTHONANYWHERE_USERNAME' with your actual username on PythonAnywhere
path = '/home/YOUR_PYTHONANYWHERE_USERNAME/mysite'
if path not in sys.path:
    sys.path.append(path)

from app import app as application
