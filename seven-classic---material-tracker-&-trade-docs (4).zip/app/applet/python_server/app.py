import os
import base64
from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
from google.genai import types

app = Flask(__name__)
CORS(app)

# Initialize Gemini Client using GEMINI_API_KEY from environment
api_key = os.environ.get("GEMINI_API_KEY")
client = genai.Client(api_key=api_key) if api_key else genai.Client()

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "running", "platform": "PythonAnywhere", "model": "gemini-3.8-flash"})

@app.route('/api/extract-document', methods=['POST'])
def extract_document():
    try:
        data = request.json or {}
        lc_file_base64 = data.get('lcFileBase64')
        lc_mime_type = data.get('lcMimeType', 'application/pdf')
        lc_file_name = data.get('lcFileName', 'LC.pdf')
        
        pi_file_base64 = data.get('piFileBase64')
        pi_mime_type = data.get('piMimeType', 'application/pdf')
        pi_file_name = data.get('piFileName', 'PI.pdf')
        
        file_base64 = data.get('fileBase64')
        mime_type = data.get('mimeType', 'application/pdf')
        file_name = data.get('fileName', 'document.pdf')
        
        text_content = data.get('textContent', '')
        prompt_text = data.get('prompt', 'Extract all commercial trade details, buyer, items, and bank info into the exact JSON schema required for Seven Classic Industries.')

        prompt_system_instructions = """You are an expert Trade & Commercial Document AI Assistant for Seven Classic Industries Ltd., Bangladesh.
Extract all details from the provided Letter of Credit (LC) and Proforma Invoice (PI) into strict JSON matching the required schema."""

        parts = []
        if lc_file_base64:
            clean_base64 = lc_file_base64.split(',')[-1]
            parts.append(types.Part.from_bytes(
                data=base64.b64decode(clean_base64),
                mime_type=lc_mime_type or 'application/pdf'
            ))
            parts.append(types.Part.from_text(text=f"DOCUMENT: Uploaded Letter of Credit (LC) file '{lc_file_name}'."))

        if pi_file_base64:
            clean_base64 = pi_file_base64.split(',')[-1]
            parts.append(types.Part.from_bytes(
                data=base64.b64decode(clean_base64),
                mime_type=pi_mime_type or 'application/pdf'
            ))
            parts.append(types.Part.from_text(text=f"DOCUMENT: Uploaded Proforma Invoice (PI) file '{pi_file_name}'."))

        if file_base64 and not lc_file_base64 and not pi_file_base64:
            clean_base64 = file_base64.split(',')[-1]
            parts.append(types.Part.from_bytes(
                data=base64.b64decode(clean_base64),
                mime_type=mime_type or 'application/pdf'
            ))
            parts.append(types.Part.from_text(text=f"DOCUMENT: Uploaded file '{file_name}'."))

        if text_content:
            parts.append(types.Part.from_text(text=f"User Provided Text / SWIFT Content:\n{text_content}"))

        parts.append(types.Part.from_text(text=prompt_text))

        response = client.models.generate_content(
            model='gemini-3.8-flash',
            contents=parts,
            config=types.GenerateContentConfig(
                system_instruction=prompt_system_instructions,
                response_mime_type='application/json',
            )
        )

        import json
        output_text = response.text or '{}'
        try:
            parsed_data = json.loads(output_text)
        except Exception:
            import re
            match = re.search(r'\{[\s\S]*\}', output_text)
            if match:
                parsed_data = json.loads(match.group(0))
            else:
                parsed_data = {"error": "Failed to parse AI response as JSON"}

        return jsonify({
            "success": True,
            "data": parsed_data,
            "source": "pythonanywhere_gemini_ai"
        })

    except Exception as e:
        print("Error in extract_document:", str(e))
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
